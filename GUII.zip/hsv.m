function varargout = hsv(varargin)
% HSV MATLAB code for hsv.fig
%      HSV, by itself, creates a new HSV or raises the existing
%      singleton*.
%
%      H = HSV returns the handle to a new HSV or the handle to
%      the existing singleton*.
%
%      HSV('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in HSV.M with the given input arguments.
%
%      HSV('Property','Value',...) creates a new HSV or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before hsv_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to hsv_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help hsv

% Last Modified by GUIDE v2.5 11-Jun-2021 09:15:37

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @hsv_OpeningFcn, ...
                   'gui_OutputFcn',  @hsv_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before hsv is made visible.
function hsv_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to hsv (see VARARGIN)

% Choose default command line output for hsv
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes hsv wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = hsv_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global fid
[f,p]=uigetfile({"*.jpg";"*.tif"},"�����ļ�");
fid=imread(strcat(p,f));
[~,~,w]=size(fid);
if w~=3
    errordlg("��������������������","error");
end

% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global fid
P=rgb2hsv(fid);
R=P(:,:,1);
G=P(:,:,2);
B=P(:,:,3);
R=255/(max(max(R))-min(min(R))).*(R-min(min(R)));
G=255/(max(max(G))-min(min(G))).*(G-min(min(G)));
B=255/(max(max(B))-min(min(B))).*(B-min(min(B)));
R=uint8(R);G=uint8(G);B=uint8(B);
FID=cat(3,R,G,B);
figure(11111)
imshow(FID)
