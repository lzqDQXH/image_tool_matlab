function varargout = tif_show(varargin)
% TIF_SHOW MATLAB code for tif_show.fig
%      TIF_SHOW, by itself, creates a new TIF_SHOW or raises the existing
%      singleton*.
%
%      H = TIF_SHOW returns the handle to a new TIF_SHOW or the handle to
%      the existing singleton*.
%
%      TIF_SHOW('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in TIF_SHOW.M with the given input arguments.
%
%      TIF_SHOW('Property','Value',...) creates a new TIF_SHOW or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before tif_show_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to tif_show_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help tif_show

% Last Modified by GUIDE v2.5 13-Jun-2021 20:43:14

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @tif_show_OpeningFcn, ...
                   'gui_OutputFcn',  @tif_show_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before tif_show is made visible.
function tif_show_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to tif_show (see VARARGIN)

% Choose default command line output for tif_show
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes tif_show wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = tif_show_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[file,path]=uigetfile({"*.tif";"*.jpg";"*.png"},"��ѡ��tif�ļ�");
if file
    paths=[fullfile(path,file)];
    set(handles.edit1,"string",paths)
end




% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu1
switch(get(handles.popupmenu1,'value'))
    case 2
        set(handles.pushbutton3,"string","Wrong")
        set(handles.edit3,"string","None")
        set(handles.edit4,"string","None")
        set(handles.edit5,"string","None")
        set(handles.pushbutton4,"string","Wrong")
        fid=imread(get(handles.edit1,"string"));
        set(handles.edit2,"string",1);
    case 3
        set(handles.text4,"string","������")
        set(handles.pushbutton3,"string","���ɫ���")
        set(handles.edit3,"string","5")
        set(handles.edit4,"string","4")
        set(handles.edit5,"string","3")
        set(handles.pushbutton4,"string","�ٲ�ɫ���")
        fid=imread(get(handles.edit1,"string"));
        A=size(fid);
        bound=A(3);
        set(handles.edit2,"string",bound);
end



% --- Executes during object creation, after setting all properties.
function popupmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
fid=imread(get(handles.edit1,"string"));
if str2num(get(handles.edit2,"string"))==1
   axes(handles.axes1),imshow(fid)
else str2num(get(handles.edit2,"string"))>=2;
    fid=fid(:,:,str2num(get(handles.edit6,"string")));
    axes(handles.axes1),imshow(fid)
end
    



% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
fid=imread(get(handles.edit1,"string"));
if str2num(get(handles.edit2,"string"))>=6
    f_rgb=fid(:,:,4:-1:2);
    axes(handles.axes2),imshow(f_rgb)
else
    f_rgb=fid(:,:,1:1:3);
    axes(handles.axes2),imshow(f_rgb)
end

    



% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
fid=imread(get(handles.edit1,"string"));
bound1=fid(:,:,str2num(get(handles.edit3,"string")));
bound2=fid(:,:,str2num(get(handles.edit4,"string")));
bound3=fid(:,:,str2num(get(handles.edit5,"string")));
f_123=cat(3,bound1,bound2,bound3);
axes(handles.axes3),imshow(f_123)



function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double


% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit4_Callback(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit4 as text
%        str2double(get(hObject,'String')) returns contents of edit4 as a double


% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit5_Callback(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit5 as text
%        str2double(get(hObject,'String')) returns contents of edit5 as a double


% --- Executes during object creation, after setting all properties.
function edit5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit6_Callback(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit6 as text
%        str2double(get(hObject,'String')) returns contents of edit6 as a double


% --- Executes during object creation, after setting all properties.
function edit6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in text8.
function text8_Callback(hObject, eventdata, handles)
% hObject    handle to text8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
wr=["����ͬ�㣬���ڶ���" "��Ӧ��Ȼ����" "����ʱ�ҷſ���" "һ����˿һ�����" "�㲻������ģ��" "���մǾ�������"];
len=length(wr);
for i=1:1:len
    set(handles.text8,"string",wr(i));
end


% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
wr=["���죬���ڶ���" "��Ӧ��Ȼ����" "������ʵ" "һ����˿һ�����" "�㲻������ģ��" "���մǾ�������" "�󵨼��裬С����֤" "һ�տ���������" "����һ������" "�������³��˾�" "��˭��������"];
len=length(wr);
i=round(10*rand(1))+1;
set(handles.pushbutton5,"string",wr(i));


% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
fid=imread(get(handles.edit1,"string"));
if str2num(get(handles.edit2,"string"))==1
   axes(handles.axes1),imhist(fid)
else str2num(get(handles.edit2,"string"))>=2;
    fid=fid(:,:,str2num(get(handles.edit6,"string")));
    axes(handles.axes1),imhist(fid)
end
t=zeros(1,256);
for j=0:1:255
     count=find(fid==j);
     t(1,j+1)=length(count);
end

 site1=find(t(1,:)==max(t(1,:)));
 set(handles.text11,"string",t(1,site1));
 set(handles.edit7,"string",site1-1);
 site2=find(t(1,:)==min(t(1,:)));
 set(handles.text15,"string",t(1,site2));
 set(handles.text14,"string",site2-1);
 
A=size(fid);
total=A(1)*A(2);
midd=zeros(1,2);
s=zeros(1,total);
for o=1:1:256
   gs=t(1,o);
   gs1=sum(t(1,1:1:o));
   gs2=gs1-gs+1;
   s(1,gs2:1:gs1)=(o-1)*ones(1,gs);
end
ssit1=total/2;
ssit2=ssit1+1;
if mod(total,2)    
    midd=s(1,round(ssit1));
    set(handles.text17,"string",midd);
else
    for mm=1:1:2
        if mm==1
         midd(1,mm)=s(1,ssit1);
        end
        if mm==2
         midd(1,mm)=s(1,ssit2);
        end
        set(handles.text17,"string",midd);
    end
end



% --- Executes during object creation, after setting all properties.
function edit7_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes on button press in pushbutton8.
function pushbutton8_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
fid=imread(get(handles.edit1,"string"));
figure(520)
imshow(fid);


% --- Executes on button press in pushbutton9.
function pushbutton9_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton10.
function pushbutton10_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
fid=imread(get(handles.edit1,"string"));
if str2num(get(handles.edit2,"string"))==1
    fid=255-fid;
    figure(2)
    imshow(fid)
else str2num(get(handles.edit2,"string"))>=2;
    fid=fid(:,:,str2num(get(handles.edit6,"string")));
    fid=255-fid;
    figure(2)
    imshow(fid)
end


% --- Executes on selection change in popupmenu4.
function popupmenu4_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu4 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu4
% global fid1 fid2 fid3 fid4;
fid=imread(get(handles.edit1,"string"));
[h,l,w]=size(fid);
maxx=max(max(fid));minn=min(min(fid));
maxx=double(maxx);minn=double(minn);
if str2double(get(handles.edit2,"string"))==1
    switch(get(handles.popupmenu4,'value'))
        case 2
           fid1=(255/(maxx-minn)).*(fid-minn);
           figure(3)
           fid1=uint8(fid1);
           subplot(1,2,1)
           imshow(fid1)
           subplot(1,2,2)
           imhist(fid1)
        case 3
            under=get(handles.edit10,"string");
            fid2=(str2double(under)).^fid;
            fid2=uint8(fid2);
            maxx=max(max(fid2));minn=min(min(fid2));
            maxx=double(maxx);minn=double(minn);
            fid2=(255/(maxx-minn)).*(fid2-minn);
            figure(4)
            subplot(1,2,1)
            imshow(fid2)
            subplot(1,2,2)
            imhist(fid2)
        case 4
            up=get(handles.edit9,"string");
            fid=double(fid);
            p=str2double(up);
            fid3=log(fid)./log(p);
            fid3=uint8(fid3);%�������֮������ת����uint8���������������
            maxx=max(max(fid3));minn=min(min(fid3));
            maxx=double(maxx);minn=double(minn);
            fid3=(255/(maxx-minn)).*(fid3-minn);
            figure(5)
            subplot(1,2,1)
            imshow(fid3)
            subplot(1,2,2)
            imhist(fid3)
        case 5
            rage=str2double(get(handles.edit8,"string"));
            if 1<=rage && rage<=100
                rage=rage*0.01;
                t=zeros(1,256);
                for i=0:1:255
                     count=find(fid==i);
                     t(1,i+1)=length(count);
                end   
                p=t./sum(t);
                pp=zeros(1,256);
                for i=1:1:256
                    pp(1,i)=sum(p(1,1:1:i));
                end
                locate1=find(pp<=rage);
                locate2=locate1(length(locate1):-1:1);
                locate=find(pp>=(1-rage));
                va1=locate2(1,1)-1;
                va2=locate(1,1)-1;
                for i=1:1:h
                    for j=1:1:l
                        if fid(i,j)<=va1
                            fid(i,j)=0;
                        end
                        if fid(i,j)>=va2
                            fid(i,j)=255;
                        end
                    end
                end
                for i=1:1:h
                    for j=1:1:l
                        if fid(i,j)~=0 && fid(i,j)~=255
                          fid4(i,j)=(255/(va2-va1-2)).*(fid(i,j)-(va1+1));
                        end
                        if fid(i,j)==0
                           fid4(i,j)=fid(i,j);
                        end
                        if fid(i,j)==255
                           fid4(i,j)=fid(i,j);
                        end
                    end
                end
             %fid4=(255/(maxx-minn)).*(fid-minn);
             fid4=uint8(fid4);
             figure(6)
             subplot(1,2,1)
             imshow(fid4)
             subplot(1,2,2)
             imhist(fid4)
            else
                set(handles.edit8,"string","����")
            end
    end
end
if str2double(get(handles.edit2,"string"))>=2
    fid=fid(:,:,str2double(get(handles.edit6,"string")));
    maxx=max(max(fid));minn=min(min(fid));
    switch(get(handles.popupmenu4,'value'))
         case 2
           fid1=(255/(maxx-minn)).*(fid-minn);
           fid1=uint8(fid1);
           figure(7)
           subplot(1,2,1)
           imshow(fid1)
           subplot(1,2,2)
           imhist(fid1)
        case 3
            under=get(handles.edit10,"string");
            fid2=(str2double(under)).^fid;
            fid2=uint8(fid2);
            maxx=max(max(fid2));minn=min(min(fid2));
            maxx=double(maxx);minn=double(minn);
            fid2=(255/(maxx-minn)).*(fid2-minn);
            figure(8)
            subplot(1,2,1)
            imshow(fid2)
            subplot(1,2,2)
            imhist(fid2)
        case 4
            up=get(handles.edit9,"string");
            fid=double(fid);
            p=str2double(up);
            fid3=log(fid)./log(p);
            fid3=uint8(fid3);
            maxx=max(max(fid3));minn=min(min(fid3));
            maxx=double(maxx);minn=double(minn);
            fid3=(255/(maxx-minn)).*(fid3-minn);
            figure(9)
            subplot(1,2,1)
            imshow(fid3)
            subplot(1,2,2)
            imhist(fid3)
        case 5
            rage=str2double(get(handles.edit8,"string"));
            if 1<=rage && rage<=100
                rage=rage*0.01;
                t=zeros(1,256);
                for i=0:1:255
                     count=find(fid==i);
                     t(1,i+1)=length(count);
                end   
                p=t./sum(t);
                pp=zeros(1,256);
                for i=1:1:256
                    pp(1,i)=sum(p(1,1:1:i));
                end
                locate1=find(pp<=rage);
                locate2=locate1(length(locate1):-1:1);
                locate=find(pp>=(1-rage));
                va1=locate2(1,1)-1;
                va2=locate(1,1)-1;
                for i=1:1:h
                    for j=1:1:l
                        if fid(i,j)<=va1
                            fid(i,j)=0;
                        end
                        if fid(i,j)>=va2
                            fid(i,j)=255;
                        end
                    end
                end
                for i=1:1:h
                    for j=1:1:l
                        if fid(i,j)~=0 && fid(i,j)~=255
                          fid4(i,j)=(255/(va2-va1-2)).*(fid(i,j)-(va1+1));
                        end
                        if fid(i,j)==0
                           fid4(i,j)=fid(i,j);
                        end
                        if fid(i,j)==255
                           fid4(i,j)=fid(i,j);
                        end
                    end
                end
%              fid4=(255/(maxx-minn)).*(fid-minn);
             fid4=uint8(fid4);
             figure(10)
             subplot(1,2,1)
             imshow(fid4)
             subplot(1,2,2)
             imhist(fid4)
            else
                set(handles.edit8,"string","����")
            end
    end    
end


% --- Executes during object creation, after setting all properties.
function popupmenu4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit8_Callback(hObject, eventdata, handles)
% hObject    handle to edit8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit8 as text
%        str2double(get(hObject,'String')) returns contents of edit8 as a double


% --- Executes during object creation, after setting all properties.
function edit8_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit9_Callback(hObject, eventdata, handles)
% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit9 as text
%        str2double(get(hObject,'String')) returns contents of edit9 as a double


% --- Executes during object creation, after setting all properties.
function edit9_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit10_Callback(hObject, eventdata, handles)
% hObject    handle to edit10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit10 as text
%        str2double(get(hObject,'String')) returns contents of edit10 as a double


% --- Executes during object creation, after setting all properties.
function edit10_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit11_Callback(hObject, eventdata, handles)
% hObject    handle to edit11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit11 as text
%        str2double(get(hObject,'String')) returns contents of edit11 as a double


% --- Executes during object creation, after setting all properties.
function edit11_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit12_Callback(hObject, eventdata, handles)
% hObject    handle to edit12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit12 as text
%        str2double(get(hObject,'String')) returns contents of edit12 as a double


% --- Executes during object creation, after setting all properties.
function edit12_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit13_Callback(hObject, eventdata, handles)
% hObject    handle to edit13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit13 as text
%        str2double(get(hObject,'String')) returns contents of edit13 as a double


% --- Executes during object creation, after setting all properties.
function edit13_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit14_Callback(hObject, eventdata, handles)
% hObject    handle to edit14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit14 as text
%        str2double(get(hObject,'String')) returns contents of edit14 as a double


% --- Executes during object creation, after setting all properties.
function edit14_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit15_Callback(hObject, eventdata, handles)
% hObject    handle to edit15 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit15 as text
%        str2double(get(hObject,'String')) returns contents of edit15 as a double


% --- Executes during object creation, after setting all properties.
function edit15_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit15 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit16_Callback(hObject, eventdata, handles)
% hObject    handle to edit16 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit16 as text
%        str2double(get(hObject,'String')) returns contents of edit16 as a double


% --- Executes during object creation, after setting all properties.
function edit16_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit16 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu6.
function popupmenu6_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu6 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu6
fid=imread(get(handles.edit1,"string"));
[h,l,w]=size(fid);fid1=zeros(h,l,3);fid2=zeros(h,l,3);fid3=zeros(h,l,3);fid4=zeros(h,l,3);
% maxx=max(max(fid));minn=min(min(fid));
% maxx=double(maxx);minn=double(minn);
band1=str2double(get(handles.edit3,"string"));
band2=str2double(get(handles.edit4,"string"));
band3=str2double(get(handles.edit5,"string"));
band=[band1 band2 band3];
if str2double(get(handles.edit2,"string"))>=2
    switch(get(handles.popupmenu6,'value'))
        case 2
           for i=1:1:3
           maxx=max(max(fid(:,:,band(i))));minn=min(min(fid(:,:,band(i))));
           maxx=double(maxx);minn=double(minn);
           fid1(:,:,i)=(255/(maxx-minn)).*(fid(:,:,band(i))-minn);
           fid1=uint8(fid1);
           figure(10)
           subplot(1,2,1)
           imshow(fid1)
           subplot(1,2,2)
           imhist(fid1)
           end
        case 3
            for i=1:1:3
            under=get(handles.edit14,"string");
            fid2(:,:,i)=(str2double(under)).^fid(:,:,band(i));
            fid2=uint8(fid2);
            maxx=max(max(fid2(:,:,i)));minn=min(min(fid2(:,:,i)));
            maxx=double(maxx);minn=double(minn);
            fid2(:,:,i)=(255/(maxx-minn)).*(fid2(:,:,i)-minn);
            figure(11)
            subplot(1,2,1)
            imshow(fid2)
            subplot(1,2,2)
            imhist(fid2)
            end
        case 4
            for i=1:1:3
            up=get(handles.edit15,"string");
            fid=double(fid);
            p=str2double(up);
            fid3=log(fid(:,:,band(i)))./log(p);
            fid3=uint8(fid3);
            maxx=max(max(fid3(:,:,i)));minn=min(min(fid3(:,:,i)));
            maxx=double(maxx);minn=double(minn);
            fid3(:,:,i)=(255/(maxx-minn)).*(fid3(:,:,i)-minn);
            figure(12)
            subplot(1,2,1)
            imshow(fid3)
            subplot(1,2,2)
            imhist(fid3)
            end
        case 5
            rage=str2double(get(handles.edit16,"string"));
            fid4=zeros(h,l,3);
            if 1<=rage && rage<=100
                rage=rage*0.01;
                t=zeros(1,256);
                for k=1:1:3
                fid5=zeros(h,l,1);
                fid5(:,:,1)=fid(:,:,band(k));
%                  maxx=max(max(fid5));minn=min(min(fid5));
%                  maxx=double(maxx);minn=double(minn);
                    for i=0:1:255
                         count=find(fid5==i);
                         t(1,i+1)=length(count);
                    end   
                    p=t./sum(t);
                    pp=zeros(1,256);
                    for i=1:1:256
                        pp(1,i)=sum(p(1,1:1:i));
                    end
                    locate1=find(pp<=rage);
                    locate2=locate1(length(locate1):-1:1);
                    locate=find(pp>=(1-rage));
                    va1=locate2(1,1)-1;
                    va2=locate(1,1)-1;
                    for i=1:1:h
                        for j=1:1:l
                            if fid5(i,j)<=va1
                                fid5(i,j)=0;
                            end
                            if fid5(i,j)>=va2
                                fid5(i,j)=255;
                            end
                        end
                    end
                    fid5=uint8(fid5);
                    for i=1:1:h
                        for j=1:1:l
                        if fid5(i,j)~=0 && fid5(i,j)~=255
                           fid4(i,j,k)=(255/(va2-va1-2)).*(fid5(i,j)-(va1+1));
                        end
                        if fid5(i,j)==0
                           fid4(i,j,k)=fid5(i,j);
                        end
                        if fid5(i,j)==255
                           fid4(i,j,k)=fid5(i,j);
                        end
                        end
                    end
%               fid4(:,:,k)=(255/(maxx-minn)).*(fid5-minn);
                end
             fid4=uint8(fid4);
             figure(13)
             subplot(1,2,1)
             imshow(fid4)
             subplot(1,2,2)
             imhist(fid4)
            else
                set(handles.edit8,"string","����")
            end
        end
end



% --- Executes during object creation, after setting all properties.
function popupmenu6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton11.
function pushbutton11_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
fid=imread(get(handles.edit1,"string"));
if str2num(get(handles.edit2,"string"))>=6
    img=fid(:,:,6:-1:4);
else
    img=fid(:,:,1:1:3);
end
[h,l,b]=size(img);
simg=zeros(h,l,3);
for i=2:h-1
    for j=2:l-1
        simg(i,j,:)=double(img(i-1,j-1,:))-double(img(i+1,j+1,:))+128;
    end
end
axes(handles.axes1),imshow(simg/255)


% --- Executes on button press in pushbutton12.
function pushbutton12_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton13.
function pushbutton13_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
fid=imread(get(handles.edit1,"string"));
if str2num(get(handles.edit2,"string"))==1
   figure(521)
   subplot(1,2,1)
   histeq(fid)
   subplot(1,2,2)
   imhist(histeq(fid))
else str2num(get(handles.edit2,"string"))>=2;
    fid=fid(:,:,str2num(get(handles.edit6,"string")));
   figure(522)
   subplot(1,2,1)
   histeq(fid)
   subplot(1,2,2)
   imhist(histeq(fid))
end


% --------------------------------------------------------------------
function zs_Callback(hObject, eventdata, handles)
% hObject    handle to zs (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)




% --------------------------------------------------------------------
function ndvi_Callback(hObject, eventdata, handles)
% hObject    handle to ndvi (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% global pp ff;
% d= dialog('Position',[300 300 250 90],'Name','ѡ��ನ���ļ�');
% btn1= uicontrol('Parent',d,...
%            'Position',[150 40 70 25],...
%            'String','�˳�',...
%            'callback','delete(gcf)');      
% btn2= uicontrol('Parent',d,...
%            'Position',[40 40 70 25],...
%            'String','����',...
%            'Callback','global ff,pp;[ff,pp]=uigetfile("*.tif")')
[ff,pp]=uigetfile("*.tif");    
fid=imread(strcat(pp,ff));[h,l,w]=size(fid);
fid=double(fid);size(ff);
if strncmpi(ff,'landsat8',8) && w>=5
    fid4=fid(:,:,4);
    fid5=fid(:,:,5);
    fid=(fid5-fid4)./(fid5+fid4);
    fidvi=fid>0.7;
%     fid=uint8(fid);
    figure(222)
    subplot(1,2,1)
    fidvi=uint8(fidvi);
    imshow(fidvi,[0 1])
    subplot(1,2,2)
    fid=255/(max(max(fid))-min(min(fid))).*(fid-min(min(fid)));
    fid=uint8(fid);
    imshow(fid)
end
    
if strncmpi(ff,'landsat7',8) && w>=4
    fid3=fid(:,:,3);
    fid4=fid(:,:,4);
    fid=(fid4-fid3)./(fid4+fid3);
    fidvi=fid>0.7;
%     fid=uint8(fid);
    figure(224)
    subplot(1,2,1)
    fidvi=uint8(fidvi);
    imshow(fidvi,[0 1])
    subplot(1,2,2)
    fid=255/(max(max(fid))-min(min(fid))).*(fid-min(min(fid)));
    fid=uint8(fid);
    imshow(fid)
end
if w<4
    errordlg("���δ���","error")
end
if not(strncmpi(ff,'landsat7',8) || strncmpi(ff,'landsat8',8))
    errordlg("�ļ�����","error")
end

% --------------------------------------------------------------------
function ndwi_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% --------------------------------------------------------------------
% function ndwi_Callback(hObject, eventdata, handles)
% % hObject    handle to ndwi (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
[ff,pp]=uigetfile("*.tif");    
fid=imread(strcat(pp,ff));[h,l,w]=size(fid);
fid=double(fid);
if strncmpi(ff,'landsat8',8) && w>=5
    fid3=fid(:,:,3);
    fid5=fid(:,:,5);
    fid=(fid3-fid5)./(fid5+fid3);
    fidwi=fid>0.1;
%     fid=uint8(fid);
    figure(222)
    subplot(1,2,1)
    fidwi=uint8(fidwi);
    imshow(fidwi,[0 1])
    subplot(1,2,2)
    fid=255/(max(max(fid))-min(min(fid))).*(fid-min(min(fid)));
    fid=uint8(fid);
    imshow(fid)
end
if strncmpi(ff,'landsat7',8) && w>=4
    fid2=fid(:,:,2);
    fid4=fid(:,:,4);
    fid=(fid2-fid4)./(fid4+fid2);
    fidwi=fid>0.1;
%     fid=uint8(fid);
    figure(223)
    subplot(1,2,1)
    fidwi=uint8(fidwi);
    imshow(fidwi,[0 1])
    subplot(1,2,2)
    fid=255/(max(max(fid))-min(min(fid))).*(fid-min(min(fid)));
    fid=uint8(fid);
    imshow(fid)
end
if w<4
    errordlg("���δ���","error")
end
if not(strncmpi(ff,'landsat7',8) || strncmpi(ff,'landsat8',8))
    errordlg("�ļ�����","error")
end

% --------------------------------------------------------------------

function xt_Callback(hObject, eventdata, handles)
% hObject    handle to xt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function fs_Callback(hObject, eventdata, handles)
% hObject    handle to fs (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
run("FS.m");
% set(tif_show,'visible','off')

% --------------------------------------------------------------------
function pz_Callback(hObject, eventdata, handles)
% hObject    handle to pz (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
run("PZ.m");


% --------------------------------------------------------------------
function kys_Callback(hObject, eventdata, handles)
% hObject    handle to kys (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
run("KYS.m");

% --------------------------------------------------------------------
function bys_Callback(hObject, eventdata, handles)
% hObject    handle to bys (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
run("BYS.m");


% --------------------------------------------------------------------
function ERZ_Callback(hObject, eventdata, handles)
% hObject    handle to ERZ (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[f,p]=uigetfile("*.jpg");
if f==0
    errordlg("�ļ������ڻ��ļ�δ����","error")
end
fid=imread(strcat(p,f));
[h,l,w]=size(fid);
if w>1
    gfid=rgb2gray(fid);
    level=graythresh(gfid);
    imgbw=im2bw(gfid,level);
end
pu=[0,1,0;1,1,1;0,1,0];
c=imdilate(imgbw,pu);
d=imerode(imgbw,pu);
e=imopen(imgbw,pu);
f=imclose(imgbw,pu);
figure(2014)
subplot(2,3,1);
imshow(fid)
title("ԭͼ")
subplot(2,3,2);
imshow(imgbw)
title("��ֵͼ")
subplot(2,3,3);
imshow(c)
title("����ͼ")
subplot(2,3,4);
imshow(d)
title("��ʴͼ")
subplot(2,3,5);
imshow(e)
title("��ͼ")
subplot(2,3,6);
imshow(f)
title("��ͼ")


% --------------------------------------------------------------------
function FFT_Callback(hObject, eventdata, handles)
% hObject    handle to FFT (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
run("FFT.m");

% --------------------------------------------------------------------
function XB_Callback(hObject, eventdata, handles)
% hObject    handle to XB (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function COLORCHANGE_Callback(hObject, eventdata, handles)
% hObject    handle to COLORCHANGE (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function LSXB_Callback(hObject, eventdata, handles)
% hObject    handle to LSXB (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function LXXB_Callback(hObject, eventdata, handles)
% hObject    handle to LXXB (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function haar_Callback(hObject, eventdata, handles)
% hObject    handle to haar (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
run("haar.m")


% --------------------------------------------------------------------
function ZCFFX_Callback(hObject, eventdata, handles)
% hObject    handle to ZCFFX (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
run("zcffx.m");


% --------------------------------------------------------------------
function hsi_Callback(hObject, eventdata, handles)
% hObject    handle to hsi (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
run("colorchange.m")


% --------------------------------------------------------------------
function Untitled_1_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Untitled_10_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
run("addnoise.m");


% --------------------------------------------------------------------
function Untitled_2_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Untitled_5_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Untitled_16_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_16 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Untitled_17_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_17 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Untitled_18_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_18 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Untitled_6_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
run("average_wave_tool.m");


% --------------------------------------------------------------------
function Untitled_7_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
run("middle_noise.m");


% --------------------------------------------------------------------
function Untitled_9_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Untitled_11_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Untitled_3_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Untitled_4_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Untitled_12_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
run("FS1.m");

% --------------------------------------------------------------------
function Untitled_13_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
run("PZ1.m");

% --------------------------------------------------------------------
function Untitled_14_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
run("KYS1.m");

% --------------------------------------------------------------------
function Untitled_15_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_15 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
run("BYS1.m");

% --------------------------------------------------------------------
function Untitled_19_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_19 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
run("LXDT.m");

% --------------------------------------------------------------------
function Untitled_20_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_20 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
run("LXDZ.m")


% --------------------------------------------------------------------
function Untitled_21_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_21 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
run("LXXB.m")


% --------------------------------------------------------------------
function Untitled_22_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_22 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Untitled_23_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_23 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Untitled_24_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_24 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Untitled_25_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_25 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Untitled_26_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_26 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Untitled_27_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_27 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Untitled_28_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_28 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Untitled_29_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_29 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Untitled_31_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_31 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Untitled_32_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_32 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Untitled_33_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_33 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
run("FJ.m");

% --------------------------------------------------------------------
function Untitled_34_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_34 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
run("HC.m");


% --------------------------------------------------------------------
function Untitled_35_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_35 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
run("hsv.m");


% --------------------------------------------------------------------
function Untitled_36_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_36 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
run("k_average.m");

% --------------------------------------------------------------------
function Untitled_37_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_37 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
run("k_middle.m");


% --------------------------------------------------------------------
function Untitled_38_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_38 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
run("LXGT.m")
