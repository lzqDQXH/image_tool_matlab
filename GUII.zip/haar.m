function varargout = haar(varargin)
% HAAR MATLAB code for haar.fig
%      HAAR, by itself, creates a new HAAR or raises the existing
%      singleton*.
%
%      H = HAAR returns the handle to a new HAAR or the handle to
%      the existing singleton*.
%
%      HAAR('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in HAAR.M with the given input arguments.
%
%      HAAR('Property','Value',...) creates a new HAAR or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before haar_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to haar_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help haar

% Last Modified by GUIDE v2.5 04-Jun-2021 06:51:10

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @haar_OpeningFcn, ...
                   'gui_OutputFcn',  @haar_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before haar is made visible.
function haar_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to haar (see VARARGIN)

% Choose default command line output for haar
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes haar wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = haar_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global fid
[f,p]=uigetfile({"*.jpg";"*.tif"},"select file");
fid=imread(strcat(p,f));



function edit4_Callback(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit4 as text
%        str2double(get(hObject,'String')) returns contents of edit4 as a double


% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit5_Callback(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit5 as text
%        str2double(get(hObject,'String')) returns contents of edit5 as a double


% --- Executes during object creation, after setting all properties.
function edit5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double


% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global fid2
[h,l,~]=size(fid2);
hdld=fid2(1:h/2,1:l/2);
hdlg=fid2(h/2+1:h,1:l/2);
hgld=fid2(1:h/2,l/2+1:l);
hglg=fid2(h/2+1:h,l/2+1:l);
% hdld=double(hdld);
% hdlg=double(hdlg);
% hgld=double(hgld);
% hglg=double(hglg);
%����ԭʼ�����ж�Ϊż��ʱ
%%%hdld
[m,n]=size(hdld);
lldd=zeros(2*m,n);
ld1=lldd;
for i=1:1:m
    lldd(2*i-1,:)=hdld(i,:);
end
for i=2:1:2*m
    ld1(i,:)=lldd(i-1,:)+lldd(i,:);
    ld1(1,:)=lldd(1,:)+lldd(2*m,:);
end
%%%hdlg
[m,n]=size(hdlg);
llgg=zeros(2*m,n);
lg1=llgg;
for i=1:1:m
    llgg(2*i-1,:)=hdlg(i,:);
end
for i=2:1:2*m
    lg1(i,:)=llgg(i-1,:)-llgg(i,:);
    lg1(1,:)=llgg(2*m,:)-llgg(1,:);
end

%%%hd
lx=ld1+lg1;
hhdd=zeros(2*m,2*n);
hd=hhdd;
for j=1:1:n
    hhdd(:,2*j-1)=lx(:,j);
end
for j=2:1:2*n
    hd(:,j)=hhdd(:,j-1)+hhdd(:,j);
    hd(:,1)=hhdd(:,2*n)+hhdd(:,1);
end

%%%hgld
[m,n]=size(hgld);
lldd=zeros(2*m,n);
ld2=lldd;
for i=1:1:m
    lldd(2*i-1,:)=hgld(i,:);
end
for i=2:1:2*m
    ld2(i,:)=lldd(i-1,:)+lldd(i,:);
    ld2(1,:)=lldd(1,:)+lldd(2*m,:);
end
%%%hglg
[m,n]=size(hglg);
llgg=zeros(2*m,n);
lg2=llgg;
for i=1:1:m
    llgg(2*i-1,:)=hglg(i,:);
end
for i=2:1:2*m
    lg2(i,:)=llgg(i-1,:)-llgg(i,:);
    lg2(1,:)=llgg(2*m,:)-llgg(1,:);
end
%%%hg
lxx=ld2+lg2;
hhgg=zeros(2*m,2*n);
hg=hhgg;
for j=1:1:n
    hhgg(:,2*j-1)=lxx(:,j);
end
for j=2:1:2*n
    hg(:,j)=hhgg(:,j-1)-hhgg(:,j);
    hg(:,1)=hhgg(:,2*n)-hhgg(:,1);
end
total=1/2.*(hd+hg);
total=uint8(total);
figure(1239)
imshow(total)
% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu1
global fid
[h,l,w]=size(fid);
tt=0;t=0;
for j=1:1:l
      if mod(j,2)
         tt=tt+1;
      end
end
for i=1:1:h
      if mod(i,2)
         t=t+1;
      end
end

if w==1
   exfid=zeros(h+1,l+1);
    for i=1:1:h
        for j=1:1:l
            exfid(i,j)=fid(i,j);
        end
    end
    exfid(1:h,l+1)=fid(:,1);
    exfid(h+1,1:l)=fid(1,:);
switch get(handles.popupmenu1,"value")
    case 1
     hd=zeros(h+1,tt);
    p=0;
    for j=1:1:l
        if mod(j,2)
            p=p+1;
            hd(1:h,p)=exfid(1:h,j)+exfid(1:h,j+1);
            hd(h+1,p)=exfid(h+1,j);
        end
    end
    ld=zeros(t,tt);
    pp=0;
    for i=1:1:h
        if mod(i,2)
           pp=pp+1;
           ld(pp,:)=hd(i,:)+hd(i+1,:);
        end
    end
    ld=1/2.*ld;
    ld=255/(max(max(ld))-min(min(ld))).*(ld-min(min(ld)));
    hdld=uint8(ld);
    hd=zeros(h+1,tt);
    p=0;
    for j=1:1:l
        if mod(j,2)
            p=p+1;
            hd(1:h,p)=exfid(1:h,j)+exfid(1:h,j+1);
            hd(h+1,p)=exfid(h+1,j);
        end
    end
    lg=zeros(t,tt);
    pp=0;
    for i=1:1:h
        if mod(i,2)
           pp=pp+1;
           lg(pp,:)=hd(i+1,:)-hd(i,:);
        end
    end
    lg=1/2.*lg;
    lg=255/(max(max(lg))-min(min(lg))).*(lg-min(min(lg)));
    hdlg=uint8(lg);
    hg=zeros(h+1,tt);
    p=0;
    for j=1:1:l
        if mod(j,2)
            p=p+1;
            hg(1:h,p)=exfid(1:h,j+1)-exfid(1:h,j);
            hg(h+1,p)=exfid(h+1,j);
        end
    end
    ld=zeros(t,tt);
    pp=0;
    for i=1:1:h
        if mod(i,2)
           pp=pp+1;
           ld(pp,:)=hg(i,:)+hg(i+1,:);
        end
    end
    ld=1/2.*ld;
    ld=255/(max(max(ld))-min(min(ld))).*(ld-min(min(ld)));
    hgld=uint8(ld);
    hg=zeros(h+1,tt);
    p=0;
    for j=1:1:l
        if mod(j,2)
            p=p+1;
            hg(1:h,p)=exfid(1:h,j+1)-exfid(1:h,j);
            hg(h+1,p)=exfid(h+1,j);
        end
    end
    lg=zeros(t,tt);
    pp=0;
    for i=1:1:h
        if mod(i,2)
           pp=pp+1;
           lg(pp,:)=hg(i+1,:)-hg(i,:);
        end
    end
    lg=1/2.*lg;
    lg=255/(max(max(lg))-min(min(lg))).*(lg-min(min(lg)));
    hglg=uint8(lg);
    [hh,ll]=size(hglg);
    total=zeros(2*hh,2*ll);
    total(1:hh,1:ll)=hdld(:,:);
    total(hh+1:2*hh,1:ll)=hdlg(:,:);
    total(1:hh,ll+1:2*ll)=hgld(:,:);
    total(hh+1:2*hh,ll+1:2*ll)=hglg(:,:);
    total=uint8(total);
    figure(1238)
    imshow(total);
    case 2 
    hd=zeros(h+1,tt);
    p=0;
    for j=1:1:l
        if mod(j,2)
            p=p+1;
            hd(1:h,p)=exfid(1:h,j)+exfid(1:h,j+1);
            hd(h+1,p)=exfid(h+1,j);
        end
    end
    ld=zeros(t,tt);
    pp=0;
    for i=1:1:h
        if mod(i,2)
           pp=pp+1;
           ld(pp,:)=hd(i,:)+hd(i+1,:);
        end
    end
    ld=1/2.*ld;
    ld=255/(max(max(ld))-min(min(ld))).*(ld-min(min(ld)));%��������
    hdld=uint8(ld);
    figure(1234)
    subplot(1,2,1)
    imshow(fid);title("ԭͼ")
    subplot(1,2,2)
    imshow(hdld);title("h00�ſ�ͼ")
    case 3
    hd=zeros(h+1,tt);
    p=0;
    for j=1:1:l
        if mod(j,2)
            p=p+1;
            hd(1:h,p)=exfid(1:h,j)+exfid(1:h,j+1);
            hd(h+1,p)=exfid(h+1,j);
        end
    end
    lg=zeros(t,tt);
    pp=0;
    for i=1:1:h
        if mod(i,2)
           pp=pp+1;
           lg(pp,:)=hd(i+1,:)-hd(i,:);
        end
    end
    lg=1/2.*lg;
    lg=255/(max(max(lg))-min(min(lg))).*(lg-min(min(lg)));
    hdlg=uint8(lg);
    figure(1235)
    subplot(1,2,1)
    imshow(fid);title("ԭͼ")
    subplot(1,2,2)
    imshow(hdlg);title("h01ˮƽϸ��ͼ")
    case 4
    hg=zeros(h+1,tt);
    p=0;
    for j=1:1:l
        if mod(j,2)
            p=p+1;
            hg(1:h,p)=exfid(1:h,j+1)-exfid(1:h,j);
            hg(h+1,p)=exfid(h+1,j);
        end
    end
    ld=zeros(t,tt);
    pp=0;
    for i=1:1:h
        if mod(i,2)
           pp=pp+1;
           ld(pp,:)=hg(i,:)+hg(i+1,:);
        end
    end
    ld=1/2.*ld;
    ld=255/(max(max(ld))-min(min(ld))).*(ld-min(min(ld)));
    hgld=uint8(ld);
    figure(1236)
    subplot(1,2,1)
    imshow(fid);title("ԭͼ")
    subplot(1,2,2)
    imshow(hgld);title("h10��ֱϸ��ͼ")
    case 5
        hg=zeros(h+1,tt);
    p=0;
    for j=1:1:l
        if mod(j,2)
            p=p+1;
            hg(1:h,p)=exfid(1:h,j+1)-exfid(1:h,j);
            hg(h+1,p)=exfid(h+1,j);
        end
    end
    lg=zeros(t,tt);
    pp=0;
    for i=1:1:h
        if mod(i,2)
           pp=pp+1;
           lg(pp,:)=hg(i+1,:)-hg(i,:);
        end
    end
    lg=1/2.*lg;
    lg=255/(max(max(lg))-min(min(lg))).*(lg-min(min(lg)));
    hglg=uint8(lg);
    figure(1237)
    subplot(1,2,1)
    imshow(fid);title("ԭͼ")
    subplot(1,2,2)
    imshow(hglg);title("h11�Խ�ϸ��ͼ")
end
end





if w==3
   ffid=rgb2gray(fid);
   exfid=zeros(h+1,l+1);
    for i=1:1:h
        for j=1:1:l
            exfid(i,j)=ffid(i,j);
        end
    end
    exfid(1:h,l+1)=ffid(:,1);
    exfid(h+1,1:l)=ffid(1,:);
 switch get(handles.popupmenu1,"value")
case 1
     hd=zeros(h+1,tt);
    p=0;
    for j=1:1:l
        if mod(j,2)
            p=p+1;
            hd(1:h,p)=exfid(1:h,j)+exfid(1:h,j+1);
            hd(h+1,p)=exfid(h+1,j);
        end
    end
    ld=zeros(t,tt);
    pp=0;
    for i=1:1:h
        if mod(i,2)
           pp=pp+1;
           ld(pp,:)=hd(i,:)+hd(i+1,:);
        end
    end
    ld=1/2.*ld;
    ld=255/(max(max(ld))-min(min(ld))).*(ld-min(min(ld)));
    hdld=uint8(ld);
    hd=zeros(h+1,tt);
    p=0;
    for j=1:1:l
        if mod(j,2)
            p=p+1;
            hd(1:h,p)=exfid(1:h,j)+exfid(1:h,j+1);
            hd(h+1,p)=exfid(h+1,j);
        end
    end
    lg=zeros(t,tt);
    pp=0;
    for i=1:1:h
        if mod(i,2)
           pp=pp+1;
           lg(pp,:)=hd(i+1,:)-hd(i,:);
        end
    end
    lg=1/2.*lg;
    lg=255/(max(max(lg))-min(min(lg))).*(lg-min(min(lg)));
    hdlg=uint8(lg);
    hg=zeros(h+1,tt);
    p=0;
    for j=1:1:l
        if mod(j,2)
            p=p+1;
            hg(1:h,p)=exfid(1:h,j+1)-exfid(1:h,j);
            hg(h+1,p)=exfid(h+1,j);
        end
    end
    ld=zeros(t,tt);
    pp=0;
    for i=1:1:h
        if mod(i,2)
           pp=pp+1;
           ld(pp,:)=hg(i,:)+hg(i+1,:);
        end
    end
    ld=1/2.*ld;
    ld=255/(max(max(ld))-min(min(ld))).*(ld-min(min(ld)));
    hgld=uint8(ld);
    hg=zeros(h+1,tt);
    p=0;
    for j=1:1:l
        if mod(j,2)
            p=p+1;
            hg(1:h,p)=exfid(1:h,j+1)-exfid(1:h,j);
            hg(h+1,p)=exfid(h+1,j);
        end
    end
    lg=zeros(t,tt);
    pp=0;
    for i=1:1:h
        if mod(i,2)
           pp=pp+1;
           lg(pp,:)=hg(i+1,:)-hg(i,:);
        end
    end
    lg=1/2.*lg;
    lg=255/(max(max(lg))-min(min(lg))).*(lg-min(min(lg)));
    hglg=uint8(lg);
    [hh,ll]=size(hglg);
    total=zeros(2*hh,2*ll);
    total(1:hh,1:ll)=hdld(:,:);
    total(hh+1:2*hh,1:ll)=hdlg(:,:);
    total(1:hh,ll+1:2*ll)=hgld(:,:);
    total(hh+1:2*hh,ll+1:2*ll)=hglg(:,:);
    total=uint8(total);
    figure(1238)
    imshow(total);
    case 2 
    hd=zeros(h+1,tt);
    p=0;
    for j=1:1:l
        if mod(j,2)
            p=p+1;
            hd(1:h,p)=exfid(1:h,j)+exfid(1:h,j+1);
            hd(h+1,p)=exfid(h+1,j);
        end
    end
    ld=zeros(t,tt);
    pp=0;
    for i=1:1:h
        if mod(i,2)
           pp=pp+1;
           ld(pp,:)=hd(i,:)+hd(i+1,:);
        end
    end
    ld=1/2.*ld;
    ld=255/(max(max(ld))-min(min(ld))).*(ld-min(min(ld)));
    hdld=uint8(ld);
    figure(1234)
    subplot(1,2,1)
    imshow(ffid,[]);title("ԭͼ")
    subplot(1,2,2)
    imshow(hdld);title("h00�ſ�ͼ")
    case 3
    hd=zeros(h+1,tt);
    p=0;
    for j=1:1:l
        if mod(j,2)
            p=p+1;
            hd(1:h,p)=exfid(1:h,j)+exfid(1:h,j+1);
            hd(h+1,p)=exfid(h+1,j);
        end
    end
    lg=zeros(t,tt);
    pp=0;
    for i=1:1:h
        if mod(i,2)
           pp=pp+1;
           lg(pp,:)=hd(i+1,:)-hd(i,:);
        end
    end
    lg=1/2.*lg;
    lg=255/(max(max(lg))-min(min(lg))).*(lg-min(min(lg)));
    hdlg=uint8(lg);
    figure(1235)
    subplot(1,2,1)
    imshow(ffid,[]);title("ԭͼ")
    subplot(1,2,2)
    imshow(hdlg);title("h01ˮƽϸ��ͼ")
    case 4
    hg=zeros(h+1,tt);
    p=0;
    for j=1:1:l
        if mod(j,2)
            p=p+1;
            hg(1:h,p)=exfid(1:h,j+1)-exfid(1:h,j);
            hg(h+1,p)=exfid(h+1,j);
        end
    end
    ld=zeros(t,tt);
    pp=0;
    for i=1:1:h
        if mod(i,2)
           pp=pp+1;
           ld(pp,:)=hg(i,:)+hg(i+1,:);
        end
    end
    ld=1/2.*ld;
    ld=255/(max(max(ld))-min(min(ld))).*(ld-min(min(ld)));
    hgld=uint8(ld);
    figure(1236)
    subplot(1,2,1)
    imshow(ffid,[]);title("ԭͼ")
    subplot(1,2,2)
    imshow(hgld);title("h10��ֱϸ��ͼ")
    case 5
        hg=zeros(h+1,tt);
    p=0;
    for j=1:1:l
        if mod(j,2)
            p=p+1;
            hg(1:h,p)=exfid(1:h,j+1)-exfid(1:h,j);
            hg(h+1,p)=exfid(h+1,j);
        end
    end
    lg=zeros(t,tt);
    pp=0;
    for i=1:1:h
        if mod(i,2)
           pp=pp+1;
           lg(pp,:)=hg(i+1,:)-hg(i,:);
        end
    end
    lg=1/2.*lg;
    lg=255/(max(max(lg))-min(min(lg))).*(lg-min(min(lg)));
    hglg=uint8(lg);
    figure(1237)
    subplot(1,2,1)
    imshow(ffid,[]);title("ԭͼ")
    subplot(1,2,2)
    imshow(hglg);title("h11�Խ�ϸ��ͼ")
end
end
if w<1 || w>3
    errordlg("���ι��ٻ����","error")
end

% --- Executes during object creation, after setting all properties.
function popupmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global fid2
[f,p]=uigetfile("*.xlsx","select file");
fid2=xlsread(strcat(p,f));


% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global fid
[h,l,w]=size(fid);
if w==1
    FFfid=fid;
end
if w==3
    FFfid=rgb2gray(fid);
end
tt=0;t=0;
for j=1:1:l
      if mod(j,2)
         tt=tt+1;
      end
end
for i=1:1:h
      if mod(i,2)
         t=t+1;
      end
end
   exfid=zeros(h+1,l+1);
    for i=1:1:h
        for j=1:1:l
            exfid(i,j)=FFfid(i,j);
        end
    end
    exfid(1:h,l+1)=FFfid(:,1);
    exfid(h+1,1:l)=FFfid(1,:);
     hd=zeros(h+1,tt);
    p=0;
    for j=1:1:l
        if mod(j,2)
            p=p+1;
            hd(1:h,p)=exfid(1:h,j)+exfid(1:h,j+1);
            hd(h+1,p)=exfid(h+1,j);
        end
    end
    ld=zeros(t,tt);
    pp=0;
    for i=1:1:h
        if mod(i,2)
           pp=pp+1;
           ld(pp,:)=hd(i,:)+hd(i+1,:);
        end
    end
    hdld=1/2.*ld;
    
    hd=zeros(h+1,tt);
    p=0;
    for j=1:1:l
        if mod(j,2)
            p=p+1;
            hd(1:h,p)=exfid(1:h,j)+exfid(1:h,j+1);
            hd(h+1,p)=exfid(h+1,j);
        end
    end
    lg=zeros(t,tt);
    pp=0;
    for i=1:1:h
        if mod(i,2)
           pp=pp+1;
           lg(pp,:)=hd(i+1,:)-hd(i,:);
        end
    end
    hdlg=1/2.*lg;
    
    hg=zeros(h+1,tt);
    p=0;
    for j=1:1:l
        if mod(j,2)
            p=p+1;
            hg(1:h,p)=exfid(1:h,j+1)-exfid(1:h,j);
            hg(h+1,p)=exfid(h+1,j);
        end
    end
    ld=zeros(t,tt);
    pp=0;
    for i=1:1:h
        if mod(i,2)
           pp=pp+1;
           ld(pp,:)=hg(i,:)+hg(i+1,:);
        end
    end
    hgld=1/2.*ld;
    
    hg=zeros(h+1,tt);
    p=0;
    for j=1:1:l
        if mod(j,2)
            p=p+1;
            hg(1:h,p)=exfid(1:h,j+1)-exfid(1:h,j);
            hg(h+1,p)=exfid(h+1,j);
        end
    end
    lg=zeros(t,tt);
    pp=0;
    for i=1:1:h
        if mod(i,2)
           pp=pp+1;
           lg(pp,:)=hg(i+1,:)-hg(i,:);
        end
    end
    hglg=1/2.*lg;
    [hh,ll]=size(hglg);
    total=zeros(2*hh,2*ll);
    total(1:hh,1:ll)=hdld(:,:);
    total(hh+1:2*hh,1:ll)=hdlg(:,:);
    total(1:hh,ll+1:2*ll)=hgld(:,:);
    total(hh+1:2*hh,ll+1:2*ll)=hglg(:,:);
   [filename, pathname, filterindex] = uiputfile({'*.xlsx'},'����ļ�');
location=strcat(pathname,filename);
xlswrite(location,total);
