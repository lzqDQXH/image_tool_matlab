function varargout = zcffx(varargin)
% ZCFFX MATLAB code for zcffx.fig
%      ZCFFX, by itself, creates a new ZCFFX or raises the existing
%      singleton*.
%
%      H = ZCFFX returns the handle to a new ZCFFX or the handle to
%      the existing singleton*.
%
%      ZCFFX('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in ZCFFX.M with the given input arguments.
%
%      ZCFFX('Property','Value',...) creates a new ZCFFX or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before zcffx_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to zcffx_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help zcffx

% Last Modified by GUIDE v2.5 04-Jun-2021 14:53:21

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @zcffx_OpeningFcn, ...
                   'gui_OutputFcn',  @zcffx_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before zcffx is made visible.
function zcffx_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to zcffx (see VARARGIN)

% Choose default command line output for zcffx
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes zcffx wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = zcffx_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[f,p]=uigetfile("*.tif","select file");
set(handles.edit4,"string",fullfile(p,f));
fid=imread(strcat(p,f));
[h,l,w]=size(fid);
set(handles.edit5,"string",w);





function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double


% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function edit5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function edit6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
fid=imread(get(handles.edit4,"string"));
f_nir=fid(:,:,str2double(get(handles.edit1,"string")));
f_r=fid(:,:,str2double(get(handles.edit2,"string")));
f_g=fid(:,:,str2double(get(handles.edit3,"string")));
%%% ������������[min max]->[0 255]
%%% ��ʾ
f_rgb=cat(3, f_nir, f_r, f_g);
f_rgb=double(f_rgb);
f_rgb_min=min(f_rgb(:));
f_rgb_max=max(f_rgb(:));
g=(f_rgb-f_rgb_min)/(f_rgb_max-f_rgb_min)*(255-0);%%%������������
g=uint8(g);
figure(12314), imshow(g, []);
%%% ͼ��ߴ�
f_d=double(fid);
[h,l,w]=size(fid);
%%% ��������
f_reshape=reshape(f_d,[h*l,w]);
%%%%%%%%%%%%%%%%%%%%%%%%%
%%% ��һ�ַ��������ݹ�ʽ���Լ����ʵ�� PCA
%%%%%%%%%%%%%%%%%%%%%%%%%
f_mean=mean(f_reshape); %%% ��ֵ
temp=f_reshape-repmat(f_mean,h*l,1);%!!!!!!!!!!!!!���������Ƴɾ������ɾ���
f_cov=(temp')*(temp)./(h*l-1); %%% Э�������
% f_cov=cov(f_reshape);
[f_vec, f_va]=eig(f_cov); %%% ������ֵ f_vec ���������� f_va
%%% ע�⣺EIG ����֮�������ֵ����������λ���Ƿ��ģ���Ҫ���й鵽��Ӧ��λ��
%%%  ��������ֵ����������
for i=1:1:w
 f_latent(i,1)=f_va(w-i+1, w-i+1);
 f_coeff(:,i)=f_vec(:,w-i+1);
end
%%%��һ\��\�����ɷ�
f_pca1=0;
f_pca2=0;
f_pca3=0;
for i=1:1:w
f_pca1=f_pca1+f_coeff(i,1)*f_d(:,:,i);
f_pca2=f_pca2+f_coeff(i,2)*f_d(:,:,i);
f_pca3=f_pca3+f_coeff(i,3)*f_d(:,:,i);
end
f_pca18=255/(max(max(f_pca1))-min(min(f_pca1))).*(f_pca1-min(min(f_pca1)));
f_pca28=255/(max(max(f_pca2))-min(min(f_pca2))).*(f_pca2-min(min(f_pca2)));
f_pca38=255/(max(max(f_pca3))-min(min(f_pca3))).*(f_pca3-min(min(f_pca3)));
f_pca8=cat(3, f_pca18, f_pca28, f_pca38);
% f_pca8=255/(max(max(f_pca8))-min(min(f_pca8))).*(f_pca8-min(min(f_pca8)));
f_pca18=uint8(f_pca18);
f_pca28=uint8(f_pca28);
f_pca38=uint8(f_pca38);
f_pca8=uint8(f_pca8);
figure(12310), imshow(f_pca18, []); title('��һ���ɷ�')
figure(12311), imshow(f_pca28, []); title('�ڶ����ɷ�') 
figure(12312), imshow(f_pca38, []); title('�������ɷ�')
figure(12313), imshow(f_pca8, []); title('һ�����������ɷֺϳ�')
