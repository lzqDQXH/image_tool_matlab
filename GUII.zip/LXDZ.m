function varargout = LXDZ(varargin)
% LXDZ MATLAB code for LXDZ.fig
%      LXDZ, by itself, creates a new LXDZ or raises the existing
%      singleton*.
%
%      H = LXDZ returns the handle to a new LXDZ or the handle to
%      the existing singleton*.
%
%      LXDZ('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in LXDZ.M with the given input arguments.
%
%      LXDZ('Property','Value',...) creates a new LXDZ or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before LXDZ_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to LXDZ_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help LXDZ

% Last Modified by GUIDE v2.5 13-Jun-2021 21:07:00

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @LXDZ_OpeningFcn, ...
                   'gui_OutputFcn',  @LXDZ_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before LXDZ is made visible.
function LXDZ_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to LXDZ (see VARARGIN)

% Choose default command line output for LXDZ
handles.output = hObject;
for i=2:1:11
set(handles.(sprintf('edit%d',i)),"visible","off")
end
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes LXDZ wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = LXDZ_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global fid w h l
[f,p]=uigetfile({"*.tif";"*.jpg"},"�����ļ�");
fid=imread(strcat(p,f));
[h,l,w]=size(fid);
if w>3
    errordlg("�������룬���δ���","error")
else
    errordlg("����ɹ�","��ʾ")
end


function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global fid w h l fffp 
 r1=str2double(get(handles.edit2,"string"));
 r2=str2double(get(handles.edit3,"string"));
 r3=str2double(get(handles.edit4,"string"));
 r4=str2double(get(handles.edit5,"string"));
 r5=str2double(get(handles.edit6,"string"));
 r6=str2double(get(handles.edit7,"string"));
 r7=str2double(get(handles.edit8,"string"));
 r8=str2double(get(handles.edit9,"string"));
 r9=str2double(get(handles.edit10,"string"));
 r10=str2double(get(handles.edit11,"string"));
hh=h/2;%y
ll=l/2;%x
fid=im2double(fid);
fpp=zeros(size(fid));
ffp=zeros(size(fid));
fffp=zeros(size(fid));
fppp=zeros(size(fid));
for n=1:1:w
    f1=fft2(fid(:,:,n));
    fp=fftshift(f1);
    fpp(:,:,n)=fp(:,:,1);
    fpp(:,:,n)=log(abs(fpp(:,:,n))+1);
    for i=1:1:h %y
        for j=1:1:l %x
            D=sqrt((i-hh)^2+(j-ll)^2);
            if r1<r2 && r1>=0 && r3<r4 && r3>=0 && r5<r6 && r5>=0 && r7<r8 && r7>=0 && r9<r10 && r9>=0
                if (D>r1 && D<r2)|| (D>r3 && D<r4)|| (D>r5 && D<r6) || (D>r7 && D<r8) || (D>r9 && D<r10)
                fp(i,j)=0;
                end
            elseif r1<r2 && r1>=0 && r3<r4 && r3>=0 && r5<r6 && r5>=0 && r7<r8 && r7>=0
                if (D>r1 && D<r2) || (D>r3 && D<r4)|| (D>r5 && D<r6) || (D>r7 && D<r8)
                fp(i,j)=0;
                end
            elseif r1<r2 && r1>=0 && r3<r4 && r3>=0 && r5<r6 && r5>=0
                if (D>r1 && D<r2) || (D>r3 && D<r4)|| (D>r5 && D<r6)
                fp(i,j)=0;
                end
            elseif r1<r2 && r1>=0 && r3<r4 && r3>=0 
                if (D>r1 && D<r2) || (D>r3 && D<r4)
                fp(i,j)=0;
                end
            elseif r1<r2 && r1>=0 
                if  D>r1 && D<r2
                fp(i,j)=0;
                end
            end
        end
    end
    fppp(:,:,n)=fp(:,:,1);
    fppp(:,:,n)=log(abs(fppp(:,:,n))+1);
    ffp(:,:,n)=ifftshift(fp);
    fffp(:,:,n)=ifft2(ffp(:,:,n));
end
figure(1323)
subplot(2,2,1)
imshow(fid,[]);title("ԭͼ")
subplot(2,2,2)
imshow(fpp,[]);title("Ƶ�ƺ��Ƶ��ͼ")
subplot(2,2,3)
imshow(fffp,[]);title("�����˲���ͼ")
subplot(2,2,4)
imshow(fppp,[]);title("�����˲�Ƶ��ͼ")
for m=1:1:w
    fffp(:,:,m)=real(fffp(:,:,m));
    fffp(:,:,m)=255/(max(max(fffp(:,:,m)))-min(min(fffp(:,:,m)))).*(fffp(:,:,m)-min(min(fffp(:,:,m))));
end
fffp=uint8(fffp);

% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global fffp
[f,p]=uiputfile("*.tif");
path=strcat(p,f);
imwrite(fffp,path);
errordlg("����ɹ�","��ʾ")


% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu1
for i=2:1:11
set(handles.(sprintf('edit%d',i)),"visible","off")
end
switch get(handles.popupmenu1,"value")
    case 2
    set(handles.edit2,"visible","on");set(handles.edit3,"visible","on");
    case 3
    set(handles.edit2,"visible","on");set(handles.edit3,"visible","on");
    set(handles.edit4,"visible","on");set(handles.edit5,"visible","on");
    case 4
    set(handles.edit2,"visible","on");set(handles.edit3,"visible","on");
    set(handles.edit4,"visible","on");set(handles.edit5,"visible","on");
    set(handles.edit6,"visible","on");set(handles.edit7,"visible","on");
    case 5
    set(handles.edit2,"visible","on");set(handles.edit3,"visible","on");
    set(handles.edit4,"visible","on");set(handles.edit5,"visible","on");
    set(handles.edit6,"visible","on");set(handles.edit7,"visible","on");
    set(handles.edit8,"visible","on");set(handles.edit9,"visible","on");
    case 6
    set(handles.edit2,"visible","on");set(handles.edit3,"visible","on");
    set(handles.edit4,"visible","on");set(handles.edit5,"visible","on");
    set(handles.edit6,"visible","on");set(handles.edit7,"visible","on");
    set(handles.edit8,"visible","on");set(handles.edit9,"visible","on");
    set(handles.edit10,"visible","on");set(handles.edit11,"visible","on");
end

% --- Executes during object creation, after setting all properties.
function popupmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double


% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit4_Callback(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit4 as text
%        str2double(get(hObject,'String')) returns contents of edit4 as a double


% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit5_Callback(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit5 as text
%        str2double(get(hObject,'String')) returns contents of edit5 as a double


% --- Executes during object creation, after setting all properties.
function edit5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit6_Callback(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit6 as text
%        str2double(get(hObject,'String')) returns contents of edit6 as a double


% --- Executes during object creation, after setting all properties.
function edit6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit7_Callback(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit7 as text
%        str2double(get(hObject,'String')) returns contents of edit7 as a double


% --- Executes during object creation, after setting all properties.
function edit7_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit8_Callback(hObject, eventdata, handles)
% hObject    handle to edit8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit8 as text
%        str2double(get(hObject,'String')) returns contents of edit8 as a double


% --- Executes during object creation, after setting all properties.
function edit8_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit9_Callback(hObject, eventdata, handles)
% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit9 as text
%        str2double(get(hObject,'String')) returns contents of edit9 as a double


% --- Executes during object creation, after setting all properties.
function edit9_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit10_Callback(hObject, eventdata, handles)
% hObject    handle to edit10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit10 as text
%        str2double(get(hObject,'String')) returns contents of edit10 as a double


% --- Executes during object creation, after setting all properties.
function edit10_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit11_Callback(hObject, eventdata, handles)
% hObject    handle to edit11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit11 as text
%        str2double(get(hObject,'String')) returns contents of edit11 as a double


% --- Executes during object creation, after setting all properties.
function edit11_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
