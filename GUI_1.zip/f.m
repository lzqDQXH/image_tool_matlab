function [d,Q]=f(a,b)
for i=1:length(a)
d=a(i);Q=b;
r=(1/2).*d;
A=pi*r.^2;
v=Q./A;
g=(v.^2/(2*9.8*100));
fprintf("AΪ%f",A)
fprintf("vΪ%f",v)
fprintf("v^2/2gΪ%f",g)
fprintf("\n")
end
end