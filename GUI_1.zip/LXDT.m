function varargout = LXDT(varargin)
% LXDT MATLAB code for LXDT.fig
%      LXDT, by itself, creates a new LXDT or raises the existing
%      singleton*.
%
%      H = LXDT returns the handle to a new LXDT or the handle to
%      the existing singleton*.
%
%      LXDT('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in LXDT.M with the given input arguments.
%
%      LXDT('Property','Value',...) creates a new LXDT or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before LXDT_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to LXDT_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help LXDT

% Last Modified by GUIDE v2.5 13-Jun-2021 20:55:33

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @LXDT_OpeningFcn, ...
                   'gui_OutputFcn',  @LXDT_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before LXDT is made visible.
function LXDT_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to LXDT (see VARARGIN)

% Choose default command line output for LXDT
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes LXDT wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = LXDT_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global fid w h l
[f,p]=uigetfile({"*.tif";"*.jpg"},"�����ļ�");
fid=imread(strcat(p,f));
[h,l,w]=size(fid);
if w>3
    errordlg("�������룬���δ���","error")
else
    errordlg("����ɹ�","��ʾ")
end


function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global fid w h l fffp
hh=h/2;%y
ll=l/2;%x
fid=im2double(fid);
r=str2double(get(handles.edit1,"string"));
fpp=zeros(size(fid));
ffp=zeros(size(fid));
fffp=zeros(size(fid));
fppp=zeros(size(fid));
for n=1:1:w
    f1=fft2(fid(:,:,n));
    fp=fftshift(f1);
    fpp(:,:,n)=fp(:,:,1);
    fpp(:,:,n)=log(abs(fpp(:,:,n))+1);
    for i=1:1:h %y
        for j=1:1:l %x
            if sqrt((i-hh)^2+(j-ll)^2)>r
                fp(i,j)=0;
            end
        end
    end
    fppp(:,:,n)=fp(:,:,1);
    fppp(:,:,n)=log(abs(fppp(:,:,n))+1);
    ffp(:,:,n)=ifftshift(fp);
    fffp(:,:,n)=ifft2(ffp(:,:,n));
end
figure(1323)
subplot(2,2,1)
imshow(fid,[]);title("ԭͼ")
subplot(2,2,2)
imshow(fpp,[]);title("Ƶ�ƺ��Ƶ��ͼ")
subplot(2,2,3)
imshow(fffp,[]);title("��ͨ�˲���ͼ")
subplot(2,2,4)
imshow(fppp,[]);title("��ͨ�˲�Ƶ��ͼ")
for m=1:1:w
    fffp(:,:,m)=real(fffp(:,:,m));
    fffp(:,:,m)=255/(max(max(fffp(:,:,m)))-min(min(fffp(:,:,m)))).*(fffp(:,:,m)-min(min(fffp(:,:,m))));
end
fffp=uint8(fffp);


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global fffp
[f,p]=uiputfile("*.tif");
path=strcat(p,f);
imwrite(fffp,path);
errordlg("����ɹ�","��ʾ")
