function varargout = average_wave_tool(varargin)
% AVERAGE_WAVE_TOOL MATLAB code for average_wave_tool.fig
%      AVERAGE_WAVE_TOOL, by itself, creates a new AVERAGE_WAVE_TOOL or raises the existing
%      singleton*.
%
%      H = AVERAGE_WAVE_TOOL returns the handle to a new AVERAGE_WAVE_TOOL or the handle to
%      the existing singleton*.
%
%      AVERAGE_WAVE_TOOL('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in AVERAGE_WAVE_TOOL.M with the given input arguments.
%
%      AVERAGE_WAVE_TOOL('Property','Value',...) creates a new AVERAGE_WAVE_TOOL or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before average_wave_tool_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to average_wave_tool_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help average_wave_tool

% Last Modified by GUIDE v2.5 13-Jun-2021 11:08:36

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @average_wave_tool_OpeningFcn, ...
                   'gui_OutputFcn',  @average_wave_tool_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before average_wave_tool is made visible.
function average_wave_tool_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to average_wave_tool (see VARARGIN)

% Choose default command line output for average_wave_tool
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes average_wave_tool wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = average_wave_tool_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global fid h l w
[f,p]=uigetfile({"*.tif";"*.jpg"},"�����ļ�");
fid=imread(strcat(p,f));
[h,l,w]=size(fid);

% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global fid h l w
hh=str2double(get(handles.edit1,"string"));
ll=str2double(get(handles.edit2,"string"));
y=round(hh/2);
x=round(ll/2);
for n=1:1:w
for i=1:1:h-hh+1
    for j=1:1:l-ll+1
        fid(i+y-1,j+x-1,n)=mean(mean(fid(i:i+hh-1,j:j+ll-1,n)));
    end
end
end
figure(10001)
fid=uint8(fid);
imshow(fid);


% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global fid
[f,p]=uiputfile("*.tif");
path=strcat(p,f);
imwrite(fid,path);
errordlg("����ɹ�","��ʾ")



function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if strcmp(get(handles.edit1,"string"),"��") || strcmp(get(handles.edit2,"string"),"��") || str2double(get(handles.edit1,"string"))~=fix(str2double(get(handles.edit1,"string"))) || str2double(get(handles.edit2,"string"))~=fix(str2double(get(handles.edit2,"string"))) || (str2double(get(handles.edit1,"string"))*str2double(get(handles.edit2,"string")))<=0
    errordlg("δ��ȷ��������","error")
elseif ~mod(str2double(get(handles.edit1,"string")),2) && ~mod(str2double(get(handles.edit2,"string")),2)
    errordlg("���н�����ȡΪ����","��ʾ")
    set(handles.edit1,"string",str2double(get(handles.edit1,"string"))+1);
    set(handles.edit2,"string",str2double(get(handles.edit2,"string"))+1);
elseif ~mod(str2double(get(handles.edit2,"string")),2) && mod(str2double(get(handles.edit1,"string")),2)
    errordlg("�н�����ȡΪ����","��ʾ")
    set(handles.edit2,"string",str2double(get(handles.edit2,"string"))+1);
elseif mod(str2double(get(handles.edit2,"string")),2) && ~mod(str2double(get(handles.edit1,"string")),2)
    errordlg("�н�����ȡΪ����","��ʾ")
    set(handles.edit1,"string",str2double(get(handles.edit1,"string"))+1);
end
    
