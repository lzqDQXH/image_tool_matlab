function varargout = colorchange(varargin)
% COLORCHANGE MATLAB code for colorchange.fig
%      COLORCHANGE, by itself, creates a new COLORCHANGE or raises the existing
%      singleton*.
%
%      H = COLORCHANGE returns the handle to a new COLORCHANGE or the handle to
%      the existing singleton*.
%
%      COLORCHANGE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in COLORCHANGE.M with the given input arguments.
%
%      COLORCHANGE('Property','Value',...) creates a new COLORCHANGE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before colorchange_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to colorchange_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help colorchange

% Last Modified by GUIDE v2.5 10-Jun-2021 22:44:23

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @colorchange_OpeningFcn, ...
                   'gui_OutputFcn',  @colorchange_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before colorchange is made visible.
function colorchange_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to colorchange (see VARARGIN)

% Choose default command line output for colorchange
handles.output = hObject;
H=imread('D:\matlab\liiuzhiqing\xinqu\H.jpg');
axes(handles.axes1);imshow(H)
S=imread('D:\matlab\liiuzhiqing\xinqu\S.jpg');
axes(handles.axes3);imshow(S)
I=imread('D:\matlab\liiuzhiqing\xinqu\I.jpg');
axes(handles.axes4);imshow(I)
RGB=imread('D:\matlab\liiuzhiqing\xinqu\RGB.jpg');
axes(handles.axes2);imshow(RGB)
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes colorchange wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = colorchange_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function text3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to text3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global fid
[f,p]=uigetfile({"*.jpg";"*.tif"},"�����ļ�");
fid=imread(strcat(p,f));
[~,~,w]=size(fid);
if w<3
    errordlg("��������������������","error");
end


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global all
[f,p]=uiputfile({'*.tif'},"ѡ�񱣴�·��");
len=length(f);
if strncmp(".tif",f(1,len-3:len),4)
    lo=strcat(p,f);
    imwrite(all,lo);
    warndlg("����ɹ�","��ʾ")
    
end

% if strncmp(".xlsx",f(1,len-4:len),5)
%      lo=strcat(p,f);
%     xlswrite(lo,fid);
% end
% if strncmp("*.tif",f(1,len-3:len),4) || strncmp("*.xlsx",f(1,len-4:len),5)
%     error("cc")
% end


% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global I S H FID
[f,p]=uigetfile({"*.mat";"*.png"},"�����ļ�");
load(strcat(p,f));
I=HSI(:,:,3);
S=HSI(:,:,2);
H=HSI(:,:,1);
[h,l]=size(H);
for i=1:1:h
    for j=1:1:l
        cz=H(i,j);
        if 0<=cz && cz<120
            R(i,j)=I(i,j)/(sqrt(3))*(1+((S(i,j)*cos(cz))/cos(60-cz)));
            B(i,j)=I(i,j)/(sqrt(3))*(1-S(i,j));
            G(i,j)=sqrt(3)*I(i,j)-R(i,j)-B(i,j);
        elseif 120<=cz && cz<240
            G(i,j)=I(i,j)/(sqrt(3))*(1+((S(i,j)*cos(cz-120))/cos(180-cz)));
            R(i,j)=I(i,j)/(sqrt(3))*(1-S(i,j));
            B(i,j)=sqrt(3)*I(i,j)-R(i,j)-G(i,j);
        elseif 240<=cz && cz<360
            B(i,j)=I(i,j)/(sqrt(3))*(1+((S(i,j)*cos(cz-240))/cos(300-cz)));
            G(i,j)=I(i,j)/(sqrt(3))*(1-S(i,j));
            R(i,j)=sqrt(3)*I(i,j)-B(i,j)-G(i,j);
        end   
    end
end
R=255/(max(max(R))-min(min(R)))*(R-min(min(R)));
G=255/(max(max(G))-min(min(G)))*(G-min(min(G)));
B=255/(max(max(B))-min(min(B)))*(B-min(min(B)));
R=uint8(R);G=uint8(G);B=uint8(B);
FID=cat(3,R,G,B);
figure(12340)
imshow(FID);


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global fid all;
[h,l,w]=size(fid);
if w==3
    R=fid(:,:,1);G=fid(:,:,2);B=fid(:,:,3);
    R=double(R);G=double(G);B=double(B);
    I=1/sqrt(3).*(R+G+B);
    S=1-3*(min(min(R,G),B)./(R+G+B));
    xt=acos((((R-G)+(R-B))./2)./(sqrt((R-G).^2+(R-B).*(G-B))));
    for i=1:1:h
        for j=1:1:l
            if G(i,j)>B(i,j)
                H(i,j)=xt(i,j);
            else
                H(i,j)=360-xt(i,j);
            end
        end
    end
switch get(handles.popupmenu1,"value")
    case 1
    all=cat(3,H,S,I);
    figure(1111)
    imshow(all)
    case 2
    I=uint8(I);S=uint8(S);H=uint8(H);
   all=cat(3,H,S,I);
    figure(1111)
    imshow(all)
    case 3
    I=255/(max(max(I))-min(min(I))).*(I-min(min(I)));
    S=255/(max(max(S))-min(min(S))).*(S-min(min(S)));
    H=255/(max(max(H))-min(min(H))).*(H-min(min(H)));
    I=uint8(I);S=uint8(S);H=uint8(H);
    all=cat(3,H,S,I);
    figure(1111)
    imshow(all)
end
end


if w>=4
    R=fid(:,:,4);G=fid(:,:,3);B=fid(:,:,2);
    R=double(R);G=double(G);B=double(B);
    I=1/sqrt(3).*(R+G+B);
    S=1-3*(min(min(R,G),B)./(R+G+B));
    xt=acos((((R-G)+(R-B))./2)./(sqrt((R-G).^2+(R-B).*(G-B))));
    for i=1:1:h
        for j=1:1:l
            if G(i,j)>B(i,j)
                H(i,j)=xt(i,j);
            else
                H(i,j)=360-xt(i,j);
            end
        end
    end
switch get(handles.popupmenu1,"value")
    case 1
    all=cat(3,H,S,I); 
    figure(1111)
    imshow(all)
    case 2
    I=uint8(I);S=uint8(S);H=uint8(H);
    all=cat(3,H,S,I);
    figure(1111)
    imshow(all)
    case 3
    I=255/(max(max(I))-min(min(I))).*(I-min(min(I)));
    S=255/(max(max(S))-min(min(S))).*(S-min(min(S)));
    H=255/(max(max(H))-min(min(H))).*(H-min(min(H)));
    I=uint8(I);S=uint8(S);H=uint8(H);
    all=cat(3,H,S,I);
    figure(1111)
    imshow(all)
end
end


% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu1


% --- Executes during object creation, after setting all properties.
function popupmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global FID
[f,p]=uiputfile("*.tif","�ļ����");
imwrite(FID,strcat(p,f))
warndlg("�ɹ����","��ʾ")


% --- Executes on button press in pushbutton7.
function pushbutton7_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global fid 
[h,l,w]=size(fid);
if w==3
    R=fid(:,:,1);G=fid(:,:,2);B=fid(:,:,3);
    R=double(R);G=double(G);B=double(B);
    I=1/sqrt(3).*(R+G+B);
    S=1-3*(min(min(R,G),B)./(R+G+B));
    xt=acos((((R-G)+(R-B))./2)./(sqrt((R-G).^2+(R-B).*(G-B))));
    for i=1:1:h
        for j=1:1:l
            if G(i,j)>B(i,j)
                H(i,j)=xt(i,j);
            else
                H(i,j)=360-xt(i,j);
            end
        end
    end
    all=cat(3,H,S,I);
end
if w>=4
    R=fid(:,:,4);G=fid(:,:,3);B=fid(:,:,2);
    R=double(R);G=double(G);B=double(B);
    I=1/sqrt(3).*(R+G+B);
    S=1-3*(min(min(R,G),B)./(R+G+B));
    xt=acos((((R-G)+(R-B))./2)./(sqrt((R-G).^2+(R-B)).*(G-B)));
    for i=1:1:h
        for j=1:1:l
            if G(i,j)>B(i,j)
                H(i,j)=xt(i,j);
            else
                H(i,j)=360-xt(i,j);
            end
        end
    end
    all=cat(3,H,S,I);
end
HSI=all;
uisave({'HSI'},'hsi');
