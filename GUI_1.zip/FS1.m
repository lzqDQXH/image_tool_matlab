function varargout = FS1(varargin)
% FS1 MATLAB code for FS1.fig
%      FS1, by itself, creates a new FS1 or raises the existing
%      singleton*.
%
%      H = FS1 returns the handle to a new FS1 or the handle to
%      the existing singleton*.
%
%      FS1('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in FS1.M with the given input arguments.
%
%      FS1('Property','Value',...) creates a new FS1 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before FS1_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to FS1_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help FS1

% Last Modified by GUIDE v2.5 08-Jun-2021 23:31:42

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @FS1_OpeningFcn, ...
                   'gui_OutputFcn',  @FS1_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before FS1 is made visible.
function FS1_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to FS1 (see VARARGIN)

% Choose default command line output for FS1
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes FS1 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = FS1_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% --- Executes during object creation, after setting all properties.
[f,p]=uigetfile("*.tif");
set(handles.edit1,"string",fullfile(p,f))
fid=imread(get(handles.edit1,"string"));
[h,l,w]=size(fid);
if w~=1
    errordlg("���δ���","error")
    set(handles.edit1,"string"," ")
end
%����һ
for i=1:1:12
    for j=1:1:12
        if i>9 && j>9
            set(handles.(sprintf('edit%d%d',i,j)),"visible","off")
        end
        if i<=9 && j>9
            set(handles.(sprintf('edit0%d%d',i,j)),"visible","off")
        end
         if i>9 && j<=9
             set(handles.(sprintf('edit%d0%d',i,j)),"visible","off")
         end
         if i<=9 && j<=9
             set(handles.(sprintf('edit0%d0%d',i,j)),"visible","off")
         end
    end
end
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called



function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double


% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global dch dk;
ch=get(handles.edit2,"string");
k=get(handles.edit3,"string");
dch=str2double(ch);
dk=str2double(k);
if dch>12 || dk>12
    errordlg("�ṹԪ�����ù�����С�ڻ����12","error")
end
if dch<=1 && dk<=1
    errordlg("�ṹԪ�����ù�С�������1","error")
else
for i=1:1:12
    for j=1:1:12
        if i>9 && j>9
            set(handles.(sprintf('edit%d%d',i,j)),"visible","off")
        end
        if i<=9 && j>9
            set(handles.(sprintf('edit0%d%d',i,j)),"visible","off")
        end
         if i>9 && j<=9
             set(handles.(sprintf('edit%d0%d',i,j)),"visible","off")
         end
         if i<=9 && j<=9
             set(handles.(sprintf('edit0%d0%d',i,j)),"visible","off")
         end
    end
end
for i=1:1:dch
    for j=1:1:dk
        if i>9 && j>9
            set(handles.(sprintf('edit%d%d',i,j)),"visible","on")
            set(handles.(sprintf('edit%d%d',i,j)),"string","0")
        end
        if i<=9 && j>9
            set(handles.(sprintf('edit0%d%d',i,j)),"visible","on")
            set(handles.(sprintf('edit0%d%d',i,j)),"string","0")
        end
         if i>9 && j<=9
             set(handles.(sprintf('edit%d0%d',i,j)),"visible","on")
             set(handles.(sprintf('edit%d0%d',i,j)),"string","0")
         end
         if i<=9 && j<=9
             set(handles.(sprintf('edit0%d0%d',i,j)),"visible","on")
             set(handles.(sprintf('edit0%d0%d',i,j)),"string","0")
         end
    end
end
end


function edit4_Callback(hObject, eventdata, handles)
% hObject    handle to edit0101 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0101 as text
%        str2double(get(hObject,'String')) returns contents of edit0101 as a double


% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0101 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0102_Callback(hObject, eventdata, handles)
% hObject    handle to edit0102 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0102 as text
%        str2double(get(hObject,'String')) returns contents of edit0102 as a double


% --- Executes during object creation, after setting all properties.
function edit0102_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0102 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0103_Callback(hObject, eventdata, handles)
% hObject    handle to edit0103 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0103 as text
%        str2double(get(hObject,'String')) returns contents of edit0103 as a double


% --- Executes during object creation, after setting all properties.
function edit0103_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0103 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0104_Callback(hObject, eventdata, handles)
% hObject    handle to edit0104 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0104 as text
%        str2double(get(hObject,'String')) returns contents of edit0104 as a double


% --- Executes during object creation, after setting all properties.
function edit0104_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0104 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0105_Callback(hObject, eventdata, handles)
% hObject    handle to edit0105 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0105 as text
%        str2double(get(hObject,'String')) returns contents of edit0105 as a double


% --- Executes during object creation, after setting all properties.
function edit0105_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0105 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0106_Callback(hObject, eventdata, handles)
% hObject    handle to edit0106 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0106 as text
%        str2double(get(hObject,'String')) returns contents of edit0106 as a double


% --- Executes during object creation, after setting all properties.
function edit0106_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0106 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0107_Callback(hObject, eventdata, handles)
% hObject    handle to edit0107 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0107 as text
%        str2double(get(hObject,'String')) returns contents of edit0107 as a double


% --- Executes during object creation, after setting all properties.
function edit0107_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0107 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0101_Callback(hObject, eventdata, handles)
% hObject    handle to edit0101 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0101 as text
%        str2double(get(hObject,'String')) returns contents of edit0101 as a double


% --- Executes during object creation, after setting all properties.
function edit0101_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0101 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0109_Callback(hObject, eventdata, handles)
% hObject    handle to edit0109 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0109 as text
%        str2double(get(hObject,'String')) returns contents of edit0109 as a double


% --- Executes during object creation, after setting all properties.
function edit0109_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0109 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0110_Callback(hObject, eventdata, handles)
% hObject    handle to edit0110 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0110 as text
%        str2double(get(hObject,'String')) returns contents of edit0110 as a double


% --- Executes during object creation, after setting all properties.
function edit0110_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0110 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0111_Callback(hObject, eventdata, handles)
% hObject    handle to edit0111 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0111 as text
%        str2double(get(hObject,'String')) returns contents of edit0111 as a double


% --- Executes during object creation, after setting all properties.
function edit0111_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0111 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0112_Callback(hObject, eventdata, handles)
% hObject    handle to edit0112 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0112 as text
%        str2double(get(hObject,'String')) returns contents of edit0112 as a double


% --- Executes during object creation, after setting all properties.
function edit0112_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0112 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0201_Callback(hObject, eventdata, handles)
% hObject    handle to edit0201 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0201 as text
%        str2double(get(hObject,'String')) returns contents of edit0201 as a double


% --- Executes during object creation, after setting all properties.
function edit0201_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0201 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0202_Callback(hObject, eventdata, handles)
% hObject    handle to edit0202 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0202 as text
%        str2double(get(hObject,'String')) returns contents of edit0202 as a double


% --- Executes during object creation, after setting all properties.
function edit0202_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0202 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0203_Callback(hObject, eventdata, handles)
% hObject    handle to edit0203 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0203 as text
%        str2double(get(hObject,'String')) returns contents of edit0203 as a double


% --- Executes during object creation, after setting all properties.
function edit0203_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0203 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0204_Callback(hObject, eventdata, handles)
% hObject    handle to edit0204 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0204 as text
%        str2double(get(hObject,'String')) returns contents of edit0204 as a double


% --- Executes during object creation, after setting all properties.
function edit0204_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0204 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0205_Callback(hObject, eventdata, handles)
% hObject    handle to edit0205 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0205 as text
%        str2double(get(hObject,'String')) returns contents of edit0205 as a double


% --- Executes during object creation, after setting all properties.
function edit0205_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0205 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0206_Callback(hObject, eventdata, handles)
% hObject    handle to edit0206 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0206 as text
%        str2double(get(hObject,'String')) returns contents of edit0206 as a double


% --- Executes during object creation, after setting all properties.
function edit0206_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0206 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0207_Callback(hObject, eventdata, handles)
% hObject    handle to edit0207 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0207 as text
%        str2double(get(hObject,'String')) returns contents of edit0207 as a double


% --- Executes during object creation, after setting all properties.
function edit0207_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0207 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0208_Callback(hObject, eventdata, handles)
% hObject    handle to edit0208 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0208 as text
%        str2double(get(hObject,'String')) returns contents of edit0208 as a double


% --- Executes during object creation, after setting all properties.
function edit0208_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0208 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0209_Callback(hObject, eventdata, handles)
% hObject    handle to edit0209 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0209 as text
%        str2double(get(hObject,'String')) returns contents of edit0209 as a double


% --- Executes during object creation, after setting all properties.
function edit0209_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0209 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0210_Callback(hObject, eventdata, handles)
% hObject    handle to edit0210 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0210 as text
%        str2double(get(hObject,'String')) returns contents of edit0210 as a double


% --- Executes during object creation, after setting all properties.
function edit0210_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0210 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0211_Callback(hObject, eventdata, handles)
% hObject    handle to edit0211 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0211 as text
%        str2double(get(hObject,'String')) returns contents of edit0211 as a double


% --- Executes during object creation, after setting all properties.
function edit0211_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0211 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0212_Callback(hObject, eventdata, handles)
% hObject    handle to edit0212 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0212 as text
%        str2double(get(hObject,'String')) returns contents of edit0212 as a double


% --- Executes during object creation, after setting all properties.
function edit0212_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0212 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0301_Callback(hObject, eventdata, handles)
% hObject    handle to edit0301 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0301 as text
%        str2double(get(hObject,'String')) returns contents of edit0301 as a double


% --- Executes during object creation, after setting all properties.
function edit0301_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0301 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0302_Callback(hObject, eventdata, handles)
% hObject    handle to edit0302 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0302 as text
%        str2double(get(hObject,'String')) returns contents of edit0302 as a double


% --- Executes during object creation, after setting all properties.
function edit0302_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0302 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0303_Callback(hObject, eventdata, handles)
% hObject    handle to edit0303 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0303 as text
%        str2double(get(hObject,'String')) returns contents of edit0303 as a double


% --- Executes during object creation, after setting all properties.
function edit0303_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0303 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0304_Callback(hObject, eventdata, handles)
% hObject    handle to edit0304 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0304 as text
%        str2double(get(hObject,'String')) returns contents of edit0304 as a double


% --- Executes during object creation, after setting all properties.
function edit0304_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0304 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0305_Callback(hObject, eventdata, handles)
% hObject    handle to edit0305 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0305 as text
%        str2double(get(hObject,'String')) returns contents of edit0305 as a double


% --- Executes during object creation, after setting all properties.
function edit0305_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0305 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0306_Callback(hObject, eventdata, handles)
% hObject    handle to edit0306 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0306 as text
%        str2double(get(hObject,'String')) returns contents of edit0306 as a double


% --- Executes during object creation, after setting all properties.
function edit0306_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0306 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0307_Callback(hObject, eventdata, handles)
% hObject    handle to edit0307 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0307 as text
%        str2double(get(hObject,'String')) returns contents of edit0307 as a double


% --- Executes during object creation, after setting all properties.
function edit0307_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0307 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0308_Callback(hObject, eventdata, handles)
% hObject    handle to edit0308 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0308 as text
%        str2double(get(hObject,'String')) returns contents of edit0308 as a double


% --- Executes during object creation, after setting all properties.
function edit0308_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0308 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0309_Callback(hObject, eventdata, handles)
% hObject    handle to edit0309 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0309 as text
%        str2double(get(hObject,'String')) returns contents of edit0309 as a double


% --- Executes during object creation, after setting all properties.
function edit0309_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0309 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0310_Callback(hObject, eventdata, handles)
% hObject    handle to edit0310 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0310 as text
%        str2double(get(hObject,'String')) returns contents of edit0310 as a double


% --- Executes during object creation, after setting all properties.
function edit0310_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0310 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0311_Callback(hObject, eventdata, handles)
% hObject    handle to edit0311 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0311 as text
%        str2double(get(hObject,'String')) returns contents of edit0311 as a double


% --- Executes during object creation, after setting all properties.
function edit0311_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0311 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0312_Callback(hObject, eventdata, handles)
% hObject    handle to edit0312 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0312 as text
%        str2double(get(hObject,'String')) returns contents of edit0312 as a double


% --- Executes during object creation, after setting all properties.
function edit0312_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0312 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0401_Callback(hObject, eventdata, handles)
% hObject    handle to edit0401 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0401 as text
%        str2double(get(hObject,'String')) returns contents of edit0401 as a double


% --- Executes during object creation, after setting all properties.
function edit0401_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0401 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0402_Callback(hObject, eventdata, handles)
% hObject    handle to edit0402 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0402 as text
%        str2double(get(hObject,'String')) returns contents of edit0402 as a double


% --- Executes during object creation, after setting all properties.
function edit0402_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0402 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0403_Callback(hObject, eventdata, handles)
% hObject    handle to edit0403 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0403 as text
%        str2double(get(hObject,'String')) returns contents of edit0403 as a double


% --- Executes during object creation, after setting all properties.
function edit0403_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0403 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0404_Callback(hObject, eventdata, handles)
% hObject    handle to edit0404 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0404 as text
%        str2double(get(hObject,'String')) returns contents of edit0404 as a double


% --- Executes during object creation, after setting all properties.
function edit0404_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0404 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0405_Callback(hObject, eventdata, handles)
% hObject    handle to edit0405 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0405 as text
%        str2double(get(hObject,'String')) returns contents of edit0405 as a double


% --- Executes during object creation, after setting all properties.
function edit0405_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0405 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0406_Callback(hObject, eventdata, handles)
% hObject    handle to edit0406 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0406 as text
%        str2double(get(hObject,'String')) returns contents of edit0406 as a double


% --- Executes during object creation, after setting all properties.
function edit0406_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0406 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0407_Callback(hObject, eventdata, handles)
% hObject    handle to edit0407 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0407 as text
%        str2double(get(hObject,'String')) returns contents of edit0407 as a double


% --- Executes during object creation, after setting all properties.
function edit0407_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0407 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0408_Callback(hObject, eventdata, handles)
% hObject    handle to edit0408 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0408 as text
%        str2double(get(hObject,'String')) returns contents of edit0408 as a double


% --- Executes during object creation, after setting all properties.
function edit0408_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0408 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0409_Callback(hObject, eventdata, handles)
% hObject    handle to edit0409 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0409 as text
%        str2double(get(hObject,'String')) returns contents of edit0409 as a double


% --- Executes during object creation, after setting all properties.
function edit0409_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0409 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0410_Callback(hObject, eventdata, handles)
% hObject    handle to edit0410 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0410 as text
%        str2double(get(hObject,'String')) returns contents of edit0410 as a double


% --- Executes during object creation, after setting all properties.
function edit0410_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0410 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0411_Callback(hObject, eventdata, handles)
% hObject    handle to edit0411 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0411 as text
%        str2double(get(hObject,'String')) returns contents of edit0411 as a double


% --- Executes during object creation, after setting all properties.
function edit0411_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0411 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0412_Callback(hObject, eventdata, handles)
% hObject    handle to edit0412 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0412 as text
%        str2double(get(hObject,'String')) returns contents of edit0412 as a double


% --- Executes during object creation, after setting all properties.
function edit0412_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0412 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0501_Callback(hObject, eventdata, handles)
% hObject    handle to edit0501 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0501 as text
%        str2double(get(hObject,'String')) returns contents of edit0501 as a double


% --- Executes during object creation, after setting all properties.
function edit0501_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0501 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0502_Callback(hObject, eventdata, handles)
% hObject    handle to edit0502 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0502 as text
%        str2double(get(hObject,'String')) returns contents of edit0502 as a double


% --- Executes during object creation, after setting all properties.
function edit0502_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0502 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0503_Callback(hObject, eventdata, handles)
% hObject    handle to edit0503 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0503 as text
%        str2double(get(hObject,'String')) returns contents of edit0503 as a double


% --- Executes during object creation, after setting all properties.
function edit0503_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0503 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0504_Callback(hObject, eventdata, handles)
% hObject    handle to edit0504 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0504 as text
%        str2double(get(hObject,'String')) returns contents of edit0504 as a double


% --- Executes during object creation, after setting all properties.
function edit0504_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0504 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0505_Callback(hObject, eventdata, handles)
% hObject    handle to edit0505 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0505 as text
%        str2double(get(hObject,'String')) returns contents of edit0505 as a double


% --- Executes during object creation, after setting all properties.
function edit0505_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0505 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0506_Callback(hObject, eventdata, handles)
% hObject    handle to edit0506 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0506 as text
%        str2double(get(hObject,'String')) returns contents of edit0506 as a double


% --- Executes during object creation, after setting all properties.
function edit0506_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0506 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0507_Callback(hObject, eventdata, handles)
% hObject    handle to edit0507 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0507 as text
%        str2double(get(hObject,'String')) returns contents of edit0507 as a double


% --- Executes during object creation, after setting all properties.
function edit0507_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0507 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0508_Callback(hObject, eventdata, handles)
% hObject    handle to edit0508 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0508 as text
%        str2double(get(hObject,'String')) returns contents of edit0508 as a double


% --- Executes during object creation, after setting all properties.
function edit0508_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0508 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0509_Callback(hObject, eventdata, handles)
% hObject    handle to edit0509 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0509 as text
%        str2double(get(hObject,'String')) returns contents of edit0509 as a double


% --- Executes during object creation, after setting all properties.
function edit0509_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0509 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0510_Callback(hObject, eventdata, handles)
% hObject    handle to edit0510 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0510 as text
%        str2double(get(hObject,'String')) returns contents of edit0510 as a double


% --- Executes during object creation, after setting all properties.
function edit0510_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0510 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0511_Callback(hObject, eventdata, handles)
% hObject    handle to edit0511 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0511 as text
%        str2double(get(hObject,'String')) returns contents of edit0511 as a double


% --- Executes during object creation, after setting all properties.
function edit0511_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0511 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0512_Callback(hObject, eventdata, handles)
% hObject    handle to edit0512 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0512 as text
%        str2double(get(hObject,'String')) returns contents of edit0512 as a double


% --- Executes during object creation, after setting all properties.
function edit0512_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0512 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0601_Callback(hObject, eventdata, handles)
% hObject    handle to edit0601 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0601 as text
%        str2double(get(hObject,'String')) returns contents of edit0601 as a double


% --- Executes during object creation, after setting all properties.
function edit0601_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0601 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0602_Callback(hObject, eventdata, handles)
% hObject    handle to edit0602 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0602 as text
%        str2double(get(hObject,'String')) returns contents of edit0602 as a double


% --- Executes during object creation, after setting all properties.
function edit0602_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0602 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0603_Callback(hObject, eventdata, handles)
% hObject    handle to edit0603 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0603 as text
%        str2double(get(hObject,'String')) returns contents of edit0603 as a double


% --- Executes during object creation, after setting all properties.
function edit0603_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0603 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0604_Callback(hObject, eventdata, handles)
% hObject    handle to edit0604 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0604 as text
%        str2double(get(hObject,'String')) returns contents of edit0604 as a double


% --- Executes during object creation, after setting all properties.
function edit0604_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0604 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0605_Callback(hObject, eventdata, handles)
% hObject    handle to edit0605 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0605 as text
%        str2double(get(hObject,'String')) returns contents of edit0605 as a double


% --- Executes during object creation, after setting all properties.
function edit0605_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0605 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0606_Callback(hObject, eventdata, handles)
% hObject    handle to edit0606 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0606 as text
%        str2double(get(hObject,'String')) returns contents of edit0606 as a double


% --- Executes during object creation, after setting all properties.
function edit0606_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0606 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0607_Callback(hObject, eventdata, handles)
% hObject    handle to edit0607 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0607 as text
%        str2double(get(hObject,'String')) returns contents of edit0607 as a double


% --- Executes during object creation, after setting all properties.
function edit0607_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0607 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0608_Callback(hObject, eventdata, handles)
% hObject    handle to edit0608 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0608 as text
%        str2double(get(hObject,'String')) returns contents of edit0608 as a double


% --- Executes during object creation, after setting all properties.
function edit0608_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0608 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0609_Callback(hObject, eventdata, handles)
% hObject    handle to edit0609 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0609 as text
%        str2double(get(hObject,'String')) returns contents of edit0609 as a double


% --- Executes during object creation, after setting all properties.
function edit0609_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0609 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0610_Callback(hObject, eventdata, handles)
% hObject    handle to edit0610 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0610 as text
%        str2double(get(hObject,'String')) returns contents of edit0610 as a double


% --- Executes during object creation, after setting all properties.
function edit0610_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0610 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0611_Callback(hObject, eventdata, handles)
% hObject    handle to edit0611 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0611 as text
%        str2double(get(hObject,'String')) returns contents of edit0611 as a double


% --- Executes during object creation, after setting all properties.
function edit0611_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0611 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0612_Callback(hObject, eventdata, handles)
% hObject    handle to edit0612 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0612 as text
%        str2double(get(hObject,'String')) returns contents of edit0612 as a double


% --- Executes during object creation, after setting all properties.
function edit0612_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0612 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0701_Callback(hObject, eventdata, handles)
% hObject    handle to edit0701 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0701 as text
%        str2double(get(hObject,'String')) returns contents of edit0701 as a double


% --- Executes during object creation, after setting all properties.
function edit0701_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0701 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0702_Callback(hObject, eventdata, handles)
% hObject    handle to edit0702 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0702 as text
%        str2double(get(hObject,'String')) returns contents of edit0702 as a double


% --- Executes during object creation, after setting all properties.
function edit0702_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0702 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0703_Callback(hObject, eventdata, handles)
% hObject    handle to edit0703 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0703 as text
%        str2double(get(hObject,'String')) returns contents of edit0703 as a double


% --- Executes during object creation, after setting all properties.
function edit0703_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0703 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0704_Callback(hObject, eventdata, handles)
% hObject    handle to edit0704 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0704 as text
%        str2double(get(hObject,'String')) returns contents of edit0704 as a double


% --- Executes during object creation, after setting all properties.
function edit0704_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0704 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0705_Callback(hObject, eventdata, handles)
% hObject    handle to edit0705 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0705 as text
%        str2double(get(hObject,'String')) returns contents of edit0705 as a double


% --- Executes during object creation, after setting all properties.
function edit0705_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0705 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0706_Callback(hObject, eventdata, handles)
% hObject    handle to edit0706 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0706 as text
%        str2double(get(hObject,'String')) returns contents of edit0706 as a double


% --- Executes during object creation, after setting all properties.
function edit0706_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0706 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0707_Callback(hObject, eventdata, handles)
% hObject    handle to edit0707 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0707 as text
%        str2double(get(hObject,'String')) returns contents of edit0707 as a double


% --- Executes during object creation, after setting all properties.
function edit0707_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0707 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0708_Callback(hObject, eventdata, handles)
% hObject    handle to edit0708 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0708 as text
%        str2double(get(hObject,'String')) returns contents of edit0708 as a double


% --- Executes during object creation, after setting all properties.
function edit0708_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0708 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0709_Callback(hObject, eventdata, handles)
% hObject    handle to edit0709 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0709 as text
%        str2double(get(hObject,'String')) returns contents of edit0709 as a double


% --- Executes during object creation, after setting all properties.
function edit0709_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0709 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0710_Callback(hObject, eventdata, handles)
% hObject    handle to edit0710 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0710 as text
%        str2double(get(hObject,'String')) returns contents of edit0710 as a double


% --- Executes during object creation, after setting all properties.
function edit0710_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0710 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0711_Callback(hObject, eventdata, handles)
% hObject    handle to edit0711 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0711 as text
%        str2double(get(hObject,'String')) returns contents of edit0711 as a double


% --- Executes during object creation, after setting all properties.
function edit0711_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0711 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0712_Callback(hObject, eventdata, handles)
% hObject    handle to edit0712 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0712 as text
%        str2double(get(hObject,'String')) returns contents of edit0712 as a double


% --- Executes during object creation, after setting all properties.
function edit0712_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0712 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0801_Callback(hObject, eventdata, handles)
% hObject    handle to edit0801 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0801 as text
%        str2double(get(hObject,'String')) returns contents of edit0801 as a double


% --- Executes during object creation, after setting all properties.
function edit0801_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0801 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0802_Callback(hObject, eventdata, handles)
% hObject    handle to edit0802 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0802 as text
%        str2double(get(hObject,'String')) returns contents of edit0802 as a double


% --- Executes during object creation, after setting all properties.
function edit0802_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0802 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0803_Callback(hObject, eventdata, handles)
% hObject    handle to edit0803 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0803 as text
%        str2double(get(hObject,'String')) returns contents of edit0803 as a double


% --- Executes during object creation, after setting all properties.
function edit0803_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0803 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0804_Callback(hObject, eventdata, handles)
% hObject    handle to edit0804 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0804 as text
%        str2double(get(hObject,'String')) returns contents of edit0804 as a double


% --- Executes during object creation, after setting all properties.
function edit0804_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0804 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0805_Callback(hObject, eventdata, handles)
% hObject    handle to edit0805 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0805 as text
%        str2double(get(hObject,'String')) returns contents of edit0805 as a double


% --- Executes during object creation, after setting all properties.
function edit0805_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0805 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0806_Callback(hObject, eventdata, handles)
% hObject    handle to edit0806 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0806 as text
%        str2double(get(hObject,'String')) returns contents of edit0806 as a double


% --- Executes during object creation, after setting all properties.
function edit0806_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0806 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0807_Callback(hObject, eventdata, handles)
% hObject    handle to edit0807 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0807 as text
%        str2double(get(hObject,'String')) returns contents of edit0807 as a double


% --- Executes during object creation, after setting all properties.
function edit0807_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0807 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0808_Callback(hObject, eventdata, handles)
% hObject    handle to edit0808 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0808 as text
%        str2double(get(hObject,'String')) returns contents of edit0808 as a double


% --- Executes during object creation, after setting all properties.
function edit0808_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0808 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0809_Callback(hObject, eventdata, handles)
% hObject    handle to edit0809 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0809 as text
%        str2double(get(hObject,'String')) returns contents of edit0809 as a double


% --- Executes during object creation, after setting all properties.
function edit0809_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0809 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0810_Callback(hObject, eventdata, handles)
% hObject    handle to edit0810 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0810 as text
%        str2double(get(hObject,'String')) returns contents of edit0810 as a double


% --- Executes during object creation, after setting all properties.
function edit0810_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0810 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0811_Callback(hObject, eventdata, handles)
% hObject    handle to edit0811 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0811 as text
%        str2double(get(hObject,'String')) returns contents of edit0811 as a double


% --- Executes during object creation, after setting all properties.
function edit0811_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0811 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0812_Callback(hObject, eventdata, handles)
% hObject    handle to edit0812 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0812 as text
%        str2double(get(hObject,'String')) returns contents of edit0812 as a double


% --- Executes during object creation, after setting all properties.
function edit0812_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0812 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0901_Callback(hObject, eventdata, handles)
% hObject    handle to edit0901 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0901 as text
%        str2double(get(hObject,'String')) returns contents of edit0901 as a double


% --- Executes during object creation, after setting all properties.
function edit0901_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0901 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0902_Callback(hObject, eventdata, handles)
% hObject    handle to edit0902 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0902 as text
%        str2double(get(hObject,'String')) returns contents of edit0902 as a double


% --- Executes during object creation, after setting all properties.
function edit0902_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0902 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0903_Callback(hObject, eventdata, handles)
% hObject    handle to edit0903 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0903 as text
%        str2double(get(hObject,'String')) returns contents of edit0903 as a double


% --- Executes during object creation, after setting all properties.
function edit0903_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0903 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0904_Callback(hObject, eventdata, handles)
% hObject    handle to edit0904 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0904 as text
%        str2double(get(hObject,'String')) returns contents of edit0904 as a double


% --- Executes during object creation, after setting all properties.
function edit0904_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0904 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0905_Callback(hObject, eventdata, handles)
% hObject    handle to edit0905 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0905 as text
%        str2double(get(hObject,'String')) returns contents of edit0905 as a double


% --- Executes during object creation, after setting all properties.
function edit0905_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0905 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0906_Callback(hObject, eventdata, handles)
% hObject    handle to edit0906 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0906 as text
%        str2double(get(hObject,'String')) returns contents of edit0906 as a double


% --- Executes during object creation, after setting all properties.
function edit0906_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0906 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0907_Callback(hObject, eventdata, handles)
% hObject    handle to edit0907 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0907 as text
%        str2double(get(hObject,'String')) returns contents of edit0907 as a double


% --- Executes during object creation, after setting all properties.
function edit0907_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0907 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0908_Callback(hObject, eventdata, handles)
% hObject    handle to edit0908 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0908 as text
%        str2double(get(hObject,'String')) returns contents of edit0908 as a double


% --- Executes during object creation, after setting all properties.
function edit0908_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0908 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0909_Callback(hObject, eventdata, handles)
% hObject    handle to edit0909 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0909 as text
%        str2double(get(hObject,'String')) returns contents of edit0909 as a double


% --- Executes during object creation, after setting all properties.
function edit0909_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0909 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0910_Callback(hObject, eventdata, handles)
% hObject    handle to edit0910 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0910 as text
%        str2double(get(hObject,'String')) returns contents of edit0910 as a double


% --- Executes during object creation, after setting all properties.
function edit0910_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0910 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0911_Callback(hObject, eventdata, handles)
% hObject    handle to edit0911 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0911 as text
%        str2double(get(hObject,'String')) returns contents of edit0911 as a double


% --- Executes during object creation, after setting all properties.
function edit0911_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0911 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit0912_Callback(hObject, eventdata, handles)
% hObject    handle to edit0912 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit0912 as text
%        str2double(get(hObject,'String')) returns contents of edit0912 as a double


% --- Executes during object creation, after setting all properties.
function edit0912_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit0912 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit1001_Callback(hObject, eventdata, handles)
% hObject    handle to edit1001 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1001 as text
%        str2double(get(hObject,'String')) returns contents of edit1001 as a double


% --- Executes during object creation, after setting all properties.
function edit1001_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1001 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit1002_Callback(hObject, eventdata, handles)
% hObject    handle to edit1002 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1002 as text
%        str2double(get(hObject,'String')) returns contents of edit1002 as a double


% --- Executes during object creation, after setting all properties.
function edit1002_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1002 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit1003_Callback(hObject, eventdata, handles)
% hObject    handle to edit1003 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1003 as text
%        str2double(get(hObject,'String')) returns contents of edit1003 as a double


% --- Executes during object creation, after setting all properties.
function edit1003_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1003 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit1004_Callback(hObject, eventdata, handles)
% hObject    handle to edit1004 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1004 as text
%        str2double(get(hObject,'String')) returns contents of edit1004 as a double


% --- Executes during object creation, after setting all properties.
function edit1004_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1004 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit1005_Callback(hObject, eventdata, handles)
% hObject    handle to edit1005 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1005 as text
%        str2double(get(hObject,'String')) returns contents of edit1005 as a double


% --- Executes during object creation, after setting all properties.
function edit1005_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1005 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit1006_Callback(hObject, eventdata, handles)
% hObject    handle to edit1006 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1006 as text
%        str2double(get(hObject,'String')) returns contents of edit1006 as a double


% --- Executes during object creation, after setting all properties.
function edit1006_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1006 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit1007_Callback(hObject, eventdata, handles)
% hObject    handle to edit1007 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1007 as text
%        str2double(get(hObject,'String')) returns contents of edit1007 as a double


% --- Executes during object creation, after setting all properties.
function edit1007_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1007 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit1008_Callback(hObject, eventdata, handles)
% hObject    handle to edit1008 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1008 as text
%        str2double(get(hObject,'String')) returns contents of edit1008 as a double


% --- Executes during object creation, after setting all properties.
function edit1008_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1008 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit1009_Callback(hObject, eventdata, handles)
% hObject    handle to edit1009 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1009 as text
%        str2double(get(hObject,'String')) returns contents of edit1009 as a double


% --- Executes during object creation, after setting all properties.
function edit1009_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1009 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit1010_Callback(hObject, eventdata, handles)
% hObject    handle to edit1010 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1010 as text
%        str2double(get(hObject,'String')) returns contents of edit1010 as a double


% --- Executes during object creation, after setting all properties.
function edit1010_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1010 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit1011_Callback(hObject, eventdata, handles)
% hObject    handle to edit1011 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1011 as text
%        str2double(get(hObject,'String')) returns contents of edit1011 as a double


% --- Executes during object creation, after setting all properties.
function edit1011_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1011 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit1012_Callback(hObject, eventdata, handles)
% hObject    handle to edit1012 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1012 as text
%        str2double(get(hObject,'String')) returns contents of edit1012 as a double


% --- Executes during object creation, after setting all properties.
function edit1012_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1012 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit1101_Callback(hObject, eventdata, handles)
% hObject    handle to edit1101 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1101 as text
%        str2double(get(hObject,'String')) returns contents of edit1101 as a double


% --- Executes during object creation, after setting all properties.
function edit1101_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1101 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit1102_Callback(hObject, eventdata, handles)
% hObject    handle to edit1102 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1102 as text
%        str2double(get(hObject,'String')) returns contents of edit1102 as a double


% --- Executes during object creation, after setting all properties.
function edit1102_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1102 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit1103_Callback(hObject, eventdata, handles)
% hObject    handle to edit1103 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1103 as text
%        str2double(get(hObject,'String')) returns contents of edit1103 as a double


% --- Executes during object creation, after setting all properties.
function edit1103_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1103 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit1104_Callback(hObject, eventdata, handles)
% hObject    handle to edit1104 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1104 as text
%        str2double(get(hObject,'String')) returns contents of edit1104 as a double


% --- Executes during object creation, after setting all properties.
function edit1104_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1104 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit1105_Callback(hObject, eventdata, handles)
% hObject    handle to edit1105 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1105 as text
%        str2double(get(hObject,'String')) returns contents of edit1105 as a double


% --- Executes during object creation, after setting all properties.
function edit1105_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1105 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit1106_Callback(hObject, eventdata, handles)
% hObject    handle to edit1106 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1106 as text
%        str2double(get(hObject,'String')) returns contents of edit1106 as a double


% --- Executes during object creation, after setting all properties.
function edit1106_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1106 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit1107_Callback(hObject, eventdata, handles)
% hObject    handle to edit1107 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1107 as text
%        str2double(get(hObject,'String')) returns contents of edit1107 as a double


% --- Executes during object creation, after setting all properties.
function edit1107_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1107 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit1108_Callback(hObject, eventdata, handles)
% hObject    handle to edit1108 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1108 as text
%        str2double(get(hObject,'String')) returns contents of edit1108 as a double


% --- Executes during object creation, after setting all properties.
function edit1108_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1108 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit1109_Callback(hObject, eventdata, handles)
% hObject    handle to edit1109 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1109 as text
%        str2double(get(hObject,'String')) returns contents of edit1109 as a double


% --- Executes during object creation, after setting all properties.
function edit1109_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1109 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit1110_Callback(hObject, eventdata, handles)
% hObject    handle to edit1110 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1110 as text
%        str2double(get(hObject,'String')) returns contents of edit1110 as a double


% --- Executes during object creation, after setting all properties.
function edit1110_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1110 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit1111_Callback(hObject, eventdata, handles)
% hObject    handle to edit1111 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1111 as text
%        str2double(get(hObject,'String')) returns contents of edit1111 as a double


% --- Executes during object creation, after setting all properties.
function edit1111_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1111 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit1112_Callback(hObject, eventdata, handles)
% hObject    handle to edit1112 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1112 as text
%        str2double(get(hObject,'String')) returns contents of edit1112 as a double


% --- Executes during object creation, after setting all properties.
function edit1112_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1112 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit1201_Callback(hObject, eventdata, handles)
% hObject    handle to edit1201 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1201 as text
%        str2double(get(hObject,'String')) returns contents of edit1201 as a double


% --- Executes during object creation, after setting all properties.
function edit1201_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1201 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit1202_Callback(hObject, eventdata, handles)
% hObject    handle to edit1202 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1202 as text
%        str2double(get(hObject,'String')) returns contents of edit1202 as a double


% --- Executes during object creation, after setting all properties.
function edit1202_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1202 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit1203_Callback(hObject, eventdata, handles)
% hObject    handle to edit1203 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1203 as text
%        str2double(get(hObject,'String')) returns contents of edit1203 as a double


% --- Executes during object creation, after setting all properties.
function edit1203_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1203 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit1204_Callback(hObject, eventdata, handles)
% hObject    handle to edit1204 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1204 as text
%        str2double(get(hObject,'String')) returns contents of edit1204 as a double


% --- Executes during object creation, after setting all properties.
function edit1204_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1204 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit1205_Callback(hObject, eventdata, handles)
% hObject    handle to edit1205 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1205 as text
%        str2double(get(hObject,'String')) returns contents of edit1205 as a double


% --- Executes during object creation, after setting all properties.
function edit1205_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1205 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit1206_Callback(hObject, eventdata, handles)
% hObject    handle to edit1206 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1206 as text
%        str2double(get(hObject,'String')) returns contents of edit1206 as a double


% --- Executes during object creation, after setting all properties.
function edit1206_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1206 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit1207_Callback(hObject, eventdata, handles)
% hObject    handle to edit1207 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1207 as text
%        str2double(get(hObject,'String')) returns contents of edit1207 as a double


% --- Executes during object creation, after setting all properties.
function edit1207_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1207 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit1208_Callback(hObject, eventdata, handles)
% hObject    handle to edit1208 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1208 as text
%        str2double(get(hObject,'String')) returns contents of edit1208 as a double


% --- Executes during object creation, after setting all properties.
function edit1208_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1208 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit1209_Callback(hObject, eventdata, handles)
% hObject    handle to edit1209 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1209 as text
%        str2double(get(hObject,'String')) returns contents of edit1209 as a double


% --- Executes during object creation, after setting all properties.
function edit1209_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1209 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit1210_Callback(hObject, eventdata, handles)
% hObject    handle to edit1210 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1210 as text
%        str2double(get(hObject,'String')) returns contents of edit1210 as a double


% --- Executes during object creation, after setting all properties.
function edit1210_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1210 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit1211_Callback(hObject, eventdata, handles)
% hObject    handle to edit1211 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1211 as text
%        str2double(get(hObject,'String')) returns contents of edit1211 as a double


% --- Executes during object creation, after setting all properties.
function edit1211_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1211 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit1212_Callback(hObject, eventdata, handles)
% hObject    handle to edit1212 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1212 as text
%        str2double(get(hObject,'String')) returns contents of edit1212 as a double


% --- Executes during object creation, after setting all properties.
function edit1212_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1212 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global newsfid
fid=imread(get(handles.edit1,"string"));
[h,l,w]=size(fid);
fid=double(fid);
ch=get(handles.edit2,"string");
k=get(handles.edit3,"string");
dch=str2double(ch);
dk=str2double(k);
for i=1:1:dch
     for j=1:1:dk
        if i>9 && j>9
            total(i,j)=str2double(get(handles.(sprintf('edit%d%d',i,j)),"string"));
        end
        if i<=9 && j>9
            total(i,j)=str2double(get(handles.(sprintf('edit0%d%d',i,j)),"string"));
        end
        if i>9 && j<=9
            total(i,j)=str2double(get(handles.(sprintf('edit%d0%d',i,j)),"string"));
        end
        if i<=9 && j<=9
            total(i,j)=str2double(get(handles.(sprintf('edit0%d0%d',i,j)),"string"));
        end
     end
end

if mod(dch*dk,2)
    mdch=round(dch/2);Dmdch=mdch-1;
    mdk=round(dk/2);Dmdk=mdk-1;
    newh=h-2*Dmdch;
    newl=l-2*Dmdk;
    newfid=zeros(newh,newl);
    total=zeros(dch,dk);
    for j=1:1:l-dk+1
        for i=1:1:h-dch+1
           newfid(i,j)=min(min(fid(i:(i+dch-1),j:(j+dk-1))-total));
        end
    end
newsfid=zeros(h,l);
for i=1:1:newh
    for j=1:1:newl
         newsfid(i+Dmdch,j+Dmdk)=newfid(i,j);
    end
end
fid=uint8(fid);newsfid=uint8(newsfid);
figure(1024)
subplot(1,2,1)
imshow(fid)
title("��ʴǰ")
subplot(1,2,2)
imshow(newsfid)
title("��ʴ��")
else
    newl=l-dk+1;
    newh=h-dch+1;
    newfid=zeros(newh,newl);
    for i=1:1:newh
        for j=1:1:newl
            newfid(i,j)=min(min(fid(i:(i+dch-1),j:(j+dk-1))-total));
        end
    end
   newsfid=zeros(h,l);
   for i=1:1:newh
       for j=1:1:newl
           newsfid(i,j)=newfid(i,j);
       end
   end
fid=uint8(fid);newsfid=uint8(newsfid);
figure(1024)
subplot(1,2,1)
imshow(fid)
title("��ʴǰ")
subplot(1,2,2)
imshow(newsfid)
title("��ʴ��")
end

% --- Executes on button press in checkbox1.
function checkbox1_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
warndlg("���ԽṹԪ�����ĸ�ֵ�����ദ�������","ע��")
% Hint: get(hObject,'Value') returns toggle state of checkbox1


% --- Executes on button press in checkbox2.
function checkbox2_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
warndlg("���ԽṹԪ�����Ϸ���ֵ�����ദ�������","ע��")
% Hint: get(hObject,'Value') returns toggle state of checkbox2


% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global newsfid
[f,p]=uiputfile("*tif","���");
imwrite(newsfid,strcat(p,f));
